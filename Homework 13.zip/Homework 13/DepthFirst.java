/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework131;



import java.util.*;
import java.io.*;
import java.util.PriorityQueue;
import java.util.Iterator;

public class DepthFirst
{

	int inf=Integer.MAX_VALUE;
			/*        A    B    C    D    E    F    G    H    I */
	int adj[][] = { 
			/* A */ { inf, 8,   inf, 10,  inf, inf, 12,  inf, inf },
			/* B */ { 8,   inf, inf, inf, 12,  18,  inf, inf, inf },
			/* C */ { inf, inf, inf, inf, inf, 2,   inf, 10,  inf },
			/* D */ { 10,  inf, inf, inf, inf, 8,   inf, inf, inf },
			/* E */ { inf, 12,  inf, inf, inf, inf, 24,  inf, inf },
			/* F */ { inf, 18,  2,   8,   inf, inf, inf, inf, inf },
			/* G */ { 12,  inf, inf, inf, 24,  inf, inf, inf, inf },
			/* H */ { inf, inf, 10,  inf, inf, inf, inf, inf, inf },
			/* I */ { inf, inf, inf, inf, inf, inf, inf, 3,   inf }
	};

	static String verLabel[] = {"A", "B", "C", "D", "E", "F", "G", "H", "I"};

	final static int MAX_ver = 9;
	final static int YES = 1;
	final static int NO = 0;

	final static String PROMPT_1 = "\nEnter starting vertex (exit to Quit): ";
	final static String PROMPT_2 = "\n\t Re-Run to check the Results !!\n ";
	final static String PROMPT_3 = "\n\t Wrong version !!\n ";


	CS401Graph g;// = new CS401Graph();


	public static void main(String[] args)
	{
		new DepthFirst().run();
	}

	void printf(String line)
	{
		System.out.println(line);
	}
	void run()
	{
		while(true) {

			g = new CS401Graph();
			System.out.print(PROMPT_1);
			Scanner sc = new Scanner (System.in);
			String start_vertex = sc.nextLine();

			if( start_vertex.compareToIgnoreCase("exit") == 0 ) {
				System.out.println(PROMPT_2);
				return;
			}

			if(validatever(start_vertex) == false) {
				System.out.println(PROMPT_3);
			} else {
				System.out.print("For starting vertex "+ start_vertex+" , the depth-first traversal produces: " );
				String result = DepthFirstTraversal(start_vertex);
				System.out.println(result);

			}
		}
	}

	boolean validatever(String ver)
	{
		for(int i =0; i< MAX_ver; i++) {
			if(ver.compareToIgnoreCase(verLabel[i]) == 0)
				return true;
		}
		return false;

	}

	String DepthFirstTraversal(String start_vertex)
	{
		String result = new String();
		// if a ver is tranvered then set the flag
		int traversed_ver_flags[] = { NO, NO, NO, NO, NO, NO, NO, NO, NO};

		Stack<String> stack = new Stack<String>();
		stack.push(start_vertex);
		result += start_vertex + ", ";
		setTraversedFlag(traversed_ver_flags, start_vertex);

		String ver = start_vertex;
		while(stack.isEmpty() == false){
			g.svc(ver);
			String next_ver = g.gvnb(ver);
			//printf(">>>>> next_ver: "+ next_ver);
			if(next_ver != null) {
				if(checkTrav(traversed_ver_flags, next_ver) == false) {
					stack.push(next_ver);
					result += next_ver + ", ";
					setTraversedFlag(traversed_ver_flags, next_ver);
					ver = next_ver;
				} else {

				}	
			} else{
				// all the Edge is being tranversed
				ver = stack.pop();
				if(ver != null) {
					g.svc(ver);
					if(g.gvnc(ver) > 0)
						stack.push(ver);
				}

			}


		}
		return result;

	}

	void setTraversedFlag(int flags[], String ver)
	{
		for(int i=0; i<MAX_ver; i++){

			if(verLabel[i].compareToIgnoreCase(ver) == 0) {
				flags[i] = YES;
				return;
			}
		}
	}

	boolean checkTrav(int flags[], String ver)
	{
		for(int i=0; i<MAX_ver; i++) {
			if(ver.compareToIgnoreCase(verLabel[i]) == 0) {
				if(flags[i] == YES)
					return true;
				else
					return false;
			}

		}
		return false;
	}




	class CS401Graph
	{

		private Vertex v[] = new Vertex[MAX_ver];
		int current_vertex_index = inf;
		String current_vertex_label = "";

		public CS401Graph()
		{

			for(int i=0; i< MAX_ver; i++) {

				v[i] = new Vertex(verLabel[i], i);

				for(int j=0; j < MAX_ver; j++) {

					if(adj[i][j] != inf) {
						Edge n = new Edge(verLabel[i], verLabel[j], adj[i][j]);
						v[i].add_Edge(n);
					}
				}
			}
		}

		public String gvnb(String ver)
		{
			if((ver.compareToIgnoreCase(current_vertex_label) != 0) && (current_vertex_index != inf) ) {
				svc(ver);
			}
			return v[current_vertex_index].getNextBestEdge();
		}

		public void svc(String ver)
		{
			for(int i=0; i<MAX_ver; i++) {
				if(ver.compareToIgnoreCase(v[i].get_label()) == 0) {
					current_vertex_index = i;
					current_vertex_label = v[i].get_label();
					break;
				}
			}
		}
		public int gvnc(String ver)
		{
			if((ver.compareToIgnoreCase(current_vertex_label) != 0) && (current_vertex_index != inf) ) {
				svc(ver);
			}
			return v[current_vertex_index].getEdgeCount();
		}
	}

}



class Vertex1 
{
	private String label;
	private int label_index;
	private int total_Edge;
	private PriorityQueue<Edge1> Edges;
	private boolean visited;

	public Vertex1(String l, int i) 
	{ 
		label = l;
		label_index = i;
		Edges = null;
		visited = false;
		total_Edge = 0;
	}

	public void add_Edge(Edge1 n) 
	{
		if (Edges == null)
			Edges = new PriorityQueue<Edge1>();
		Edges.add(n);
		total_Edge++;
	}

	public Edge1 remove_Edge() 
	{
		Edge1 n = null;

		if (Edges.size() > 0)  {
			n = Edges.peek();
			Edges.remove(n);
			total_Edge--;
		}
		if ( n== null)
			total_Edge = 0; 
		return n;
	}


	public int getEdgeCount()
	{
		return total_Edge;
	}

	public String getNextBestEdge()
	{
		Edge1 neigh = remove_Edge();
		if(neigh != null)
			return neigh.label();
		else
			return null;
	}

	public String get_label() { return label; }

	public String toString()
	{
		String s = "Vertex: " + label + "\n";

		s += " Edges: \n";

		Iterator<Edge1> itr = Edges.iterator();
		while (itr.hasNext())  {
			Edge1 n = itr.next();
			s += n;
		}

		return s;
	}
}

class Edge1 implements Comparable<Edge1>
{
	private String source;
	private String destination;
	private Integer cost;

	public Edge1(String s, String d, int w)
	{
		source = s; destination = d; cost = w;
	}

	public int compareTo(Edge1 o)
	{
		if (this.cost < o.cost) return -1;
		else if (this.cost > o.cost) return 1;
		else return 0;
	}

	public String label()
	{
		return destination;
	}
	public String toString()
	{
		return "  " + destination + ", cost: " + cost + "\n";
	}
}



