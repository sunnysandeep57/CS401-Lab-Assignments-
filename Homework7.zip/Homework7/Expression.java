package homework7;

public class Expression {
	private String name;
	private int value;
	
	public Expression(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
	
	public boolean equals(Object obj) {
		Expression ne = (Expression) obj;
		return this.name.equals(ne.name);
	}
	
}


