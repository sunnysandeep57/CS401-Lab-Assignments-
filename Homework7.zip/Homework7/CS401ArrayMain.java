package homework7;

import java.io.*;

public class CS401ArrayMain{
	public static void main(String[] args){
		CS401StackArrayImpl<String> llm = new CS401StackArrayImpl<String>(10);
		
		llm.push("a");
		llm.push("b");
		llm.push("c");
		llm.push("d");
		llm.push("e");
		llm.push("f");
		llm.push("g");
		llm.push("h");
		llm.push("i");
		llm.push("j");
		
		System.out.println("Size of the list is:"+ llm.size());
		
		llm.push("k");
		
		System.out.println("Size of the list is:"+ llm.size());
		
		System.out.println("Deleted : "+ llm.pop());
		System.out.println("Deleted : "+ llm.pop());
		
		System.out.println(llm.peek());
		
		System.out.println("Size of the list is:"+ llm.size());
		
	}
}