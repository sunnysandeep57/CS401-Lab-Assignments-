package homework7;

public class CS401QueueArrayFixedMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CS401QueueArrayFixedImpl<String> qaf= new CS401QueueArrayFixedImpl<String>(10);
		
		qaf.add("a");
		qaf.add("b");
		qaf.add("c");
		qaf.add("d");
		qaf.add("e");
		qaf.add("f");
		qaf.add("g");
		qaf.add("h");
		qaf.add("i");
		qaf.add("j");
		
		System.out.println("Size of the queue is: " + qaf.size());
		
		qaf.add("k");
		
		System.out.println("Size of the queue is: " + qaf.size());
		
		System.out.println("Deleted : " + qaf.remove());
		System.out.println("Deleted : " + qaf.remove());
		
		System.out.println(qaf.peek());
		
		System.out.println("Size of the queue is: " + qaf.size());
		
	}

}
