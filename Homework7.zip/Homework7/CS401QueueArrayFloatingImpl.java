package homework7;

/* 
 * Floating front and back implementation of a queue using an array */

public class CS401QueueArrayFloatingImpl<E> implements CS401QueueInterface<E>  {
   private E[] data;
   private int front, back;
   private int capacity;
   int num_elems = 0;

   public CS401QueueArrayFloatingImpl(int num_elems)   {
      capacity = num_elems;
      data = (E[]) new Object[capacity];
      front = back = 0;    
   }

   public void add(E element) {

      /*** Add code ***/
      if(num_elems < capacity - 1){
        data[num_elems] = element;
        num_elems++;
      }else{
    	  E[] temp = (E[]) new Object[data.length + 1];
          for (int i = 0; i< data.length ; i++){
              temp[i] = data[i];
          }
          data = temp;
          data[num_elems] = element;
          num_elems++;
          capacity++;
      }
   }

   public E remove()  {
      
      /*** Add code ***/
      if(num_elems == 0){
          return null;
      }
      E temp = data[0];
      for (int i = 0; i < num_elems - 1; i++){
          data[i] = data[i+1];
      }
      num_elems--;
      return temp;

   }
   @Override
   public E peek()  {

//      /*** Add code ***/
	if(num_elems > 0){
        return data[0];
    }
    return null;
}

   public boolean is_empty()  {

      /*** Add code ***/
      if(num_elems == 0){
          return true;
      }
      return false;

   }

   public boolean is_full()  {

      /*** Add code ***/
      if(num_elems == capacity - 1){
          return true;
      }
      return false;

   }

@Override
public int size() {
	// TODO Auto-generated method stub
	return num_elems;
}



}