package homework7;

/* 
 * Fixed front implementation of a Queue using arrays */

public class CS401QueueArrayFixedImpl<E> implements CS401QueueInterface<E>  {
   private E[] data;
   private int front, back;
   private int capacity;
   private int num_elements;

   public CS401QueueArrayFixedImpl(int num_elems)   {
      capacity = num_elems;
      data = (E[]) new Object[capacity];
      front = back = 0;    
      num_elements = 0;
   }

   public void add(E element) {

      /*** Add code ***/
      if(num_elements <= capacity - 1){
        data[num_elements] = element;
        num_elements++;
      }else{
    	  E[] temp = (E[]) new Object[data.length + 1];
          for (int i = 0; i< data.length ; i++){
              temp[i] = data[i];
          }
          data = temp;
          data[num_elements] = element;
          num_elements++;
          capacity++;
      }
   }

   public E remove()  {
      
      /*** Add code ***/
      if(num_elements == 0){
          return null;
      }
      E temp = data[0];
      for (int i = 0; i < num_elements - 1; i++){
          data[i] = data[i+1];
      }
      num_elements--;
      return temp;
   }

   public E peek()  {

      /*** Add code ***/
      if(num_elements > 0){
          return data[0];
      }
      return null;
   }

   public boolean is_empty()  {

      /*** Add code ***/
      if(num_elements == 0){
          return true;
      }
      return false;
   }

   public boolean is_full()  {

      /*** Add code ***/
      if(num_elements == capacity - 1){
          return true;
      }
      return false;
   }

@Override
public int size() {
	// TODO Auto-generated method stub
	return num_elements;
}
}