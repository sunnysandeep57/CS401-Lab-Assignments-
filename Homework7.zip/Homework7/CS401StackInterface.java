/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework7;

/**
 *
 * @author Itzsunnysandeep
 */
public interface CS401StackInterface<E>
{
   /**
    * Remove the top element on the stack.
    * 
    * @return the first element on the stack.
    */
   public E pop();
   /**
    * Get the top element on the stack without removing it.
    * 
    * @return the first element on the stack.
    */
   public E peek();
   /**
    * Adds an element on the top of the stack.
    * 
    * @param e - The element to be added to the stack.
    */
   public void push(E e);

   /**
    * Determines the number of elements in this data structure.
    * 
    * @return the number of elements currently resident in this
    *         data structure.
    */
   public int size();
}
