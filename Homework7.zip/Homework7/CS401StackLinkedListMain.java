package homework7;


public class CS401StackLinkedListMain{
	public static void main(String[] args){
		CS401StackLinkedListImpl<String> llm = new CS401StackLinkedListImpl<String>();
		
		llm.push("a");
		llm.push("b");
		llm.push("c");
		llm.push("d");
		llm.push("e");
		llm.push("f");
		llm.push("g");
		llm.push("h");
		llm.push("i");
		llm.push("j");
		
		System.out.println("Size of the list is:"+ llm.size());
		
		llm.push("k");
		
		System.out.println("Size of the list is:"+ llm.size());
		
		System.out.println("Deleted : "+ llm.pop());
		System.out.println("Deleted : "+ llm.pop());
		
		System.out.println(llm.peek());
		
		System.out.println("Size of the list is:"+ llm.size());
		
	}
}