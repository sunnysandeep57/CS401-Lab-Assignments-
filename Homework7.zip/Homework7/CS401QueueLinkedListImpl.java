/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework7;

/**
 *
 * @author Itzsunnysandeep
 */
public class CS401QueueLinkedListImpl<E> implements CS401QueueInterface<E>  {
   private LinkEntry<E> head;
   private LinkEntry<E> tail;
   private int num_elements;

   public void add(E element) {

      /*** Add code ***/
      LinkEntry node = new LinkEntry();
      node.element = element;
      if(num_elements == 0){
          head = tail= node;
      }
      else{
          tail.next = node;
          tail = node;
      }
      num_elements++;
   }

   public E remove()  {
      
      /*** Add code ***/
      if(num_elements > 0){
          E temp = head.element;
          head = head.next;
          num_elements--;
          return temp;
      }else{
          return null;
      }

   }
   public E peek()  {

      /*** Add code ***/
      if(num_elements > 0){
          return head.element;
      }
      return null;
   }

   public boolean is_empty()  {

      /*** Add code ***/
      if(num_elements == 0){
          return true;
      }
      return false;
   }

   public boolean is_full()  {

      /*** Add code ***/
      return false;
   }

   /* ------------------------------------------------------------------- */
   /* Inner classes                                                      */
   protected class LinkEntry<E>
   {
      protected E element;
      protected LinkEntry<E> next;

      protected LinkEntry() { element = null; next = null; }
   }

@Override
public int size() {
	// TODO Auto-generated method stub
	return num_elements;
}
}