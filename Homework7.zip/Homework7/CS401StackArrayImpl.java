/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework7;

/**
 *
 * @author Itzsunnysandeep
 */
public class CS401StackArrayImpl<E> implements CS401StackInterface<E> 
{
   private int num_elements;
   private int max_elements;
   private E[] elements;

   public CS401StackArrayImpl(int n)
   {
      max_elements = n; 
      num_elements = 0;
      elements = (E[]) new Object[max_elements];
   }
   /**
    * Push an element on the stack.  If the stack is full, then allocate
    * more memory to hold a new stack, copy existing elements to the new
    * stack and add the new element to the newly enlarged stack.
    * Do not use System.arraycopy().  You are essentially implementing
    * what System.arraycopy() will do when you expand an existing array. **/
   public void push(E e)
   {
      /** Add code here **/
       if(num_elements == max_elements){
           E[] temp = (E[]) new Object[elements.length + 1];
           for (int i = 0; i< elements.length ; i++){
               temp[i] = elements[i];
           }
           elements = temp;
           elements[num_elements] = e;
           num_elements++;
           max_elements++;
       }else{
    	   elements[num_elements] = e;
           num_elements++;
       }
      return;
   }

   public E pop()
   {
      /** Add code here **/
       E temp = elements[num_elements - 1];
       num_elements--;
       return temp;
   }

   public E peek()
   {
      /** Add code here **/
       return elements[num_elements-1];
   }

   public int size()
   {
      /** Add code here **/
       return num_elements;
   }
   
//   public static void main(String args[]){
//       CS401StackArrayImpl ob = new CS401StackArrayImpl(10);
//       ob.pu
       
//   }
} /* CS401StackArrayImpl<E> */