/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package homework14;
class MST {
	private static final int V = 6;
	int minmumKey(int key[], Boolean mstSet[]) {
		int min = Integer.MAX_VALUE, min_index = -1;
		for (int v = 0; v < V; v++) {
			if (mstSet[v] == false && key[v] < min) {
				min = key[v];
				min_index = v;
			}
		}
		return min_index;
	}

	void printMST(int p[], int n, int graph[][]) {
		int sum = 0;
		for (int i = 1; i < V; i++) {
			System.out.println("Add Edges< " + p[i] + " ,  " + i + ",  " + (float) graph[i][p[i]] + ">");
			sum = sum + graph[i][p[i]];
		}
		System.out.println("Total cost: " + sum);
	}

	void primMST(int graph[][]) {
		int p[] = new int[V];
		int key[] = new int[V];
		Boolean mstSet[] = new Boolean[V];
		for (int i = 0; i < V; i++) {
			key[i] = Integer.MAX_VALUE;
			mstSet[i] = false;
		}
		key[0] = 0;
		p[0] = -1;
		// The MST will have V vertices
		for (int count = 0; count < V - 1; count++) {
			int u = minmumKey(key, mstSet);
			mstSet[u] = true;
			for (int v = 0; v < V; v++) {
				if (graph[u][v] != 0 && mstSet[v] == false && graph[u][v] < key[v]) {
					p[v] = u;
					key[v] = graph[u][v];
				}
			}
		}
		printMST(p, V, graph);
	}

	public static void main(String[] args) {
		MST t = new MST();
		int graph[][] = new int[][] { 
										{ 0, 6, 5, 1, 0, 0 },
										{ 6, 0, 0, 5, 3, 0 }, 
										{ 5, 0, 0, 5, 0, 2 },
										{ 1, 5, 5, 0, 6, 4 },
										{ 0, 3, 0, 6, 0, 5 },
										{ 0, 0, 2, 4, 5, 0 } 
									};
		// Print the solution
	    System.out.println("Begin Spanning Tree Prim ");
//	    System.out.println("\n");
		t.primMST(graph);
		
	}
}
