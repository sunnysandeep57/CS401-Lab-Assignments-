/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework8;
import java.util.*;

public class CarWash
{
     public final static String Overflow = " (Overflow)\n";
     
     public final static String HEADING = "\n\nTime\tEvent\t\tWaiting Time\n";
     public final static int MAX_SIZE = 5; 
     protected Queue<Car> carQueue;  
     protected LinkedList<String> results;  
     protected int  
		           	next_Arrival_Time,
		           	current_Time,
		           	sum_Of_Waiting_Times,   
		           	over_Flow_Count,
		           	number_Of_Cars,
                    waiting_Time,
                    total_Arrived_Cars,
                    mean_Service_Time,
                    next_Departure_Time,
                    max_Arrival_Time,
                    mean_Arrival_Time;
     

     protected Random random;
     protected static int RANDOM_SEED = 100;

     public CarWash(int mean_Arrival_Time, int mean_Service_Time, int max_Arrival_Time)
     {
         carQueue = new LinkedList<Car>();
         results = new LinkedList<String>();
         random = new Random(RANDOM_SEED);
         results.add (HEADING);
         this.mean_Arrival_Time = mean_Arrival_Time;
         this.mean_Service_Time = mean_Service_Time;
         this.max_Arrival_Time = max_Arrival_Time;
         this.next_Arrival_Time = getArrivalTime();
         current_Time = 0;
         number_Of_Cars = 0;
         waiting_Time = 0;
         sum_Of_Waiting_Times = 0;
         next_Departure_Time = max_Arrival_Time;  
     } 
     
     public void Process()
     {
    	 while(next_Arrival_Time < max_Arrival_Time)
    	 
    	 {
			total_Arrived_Cars=total_Arrived_Cars+1;
			NextCar(next_Arrival_Time);
			next_Arrival_Time = getArrivalTime();
    	 }
    	 finish();
     }
     
     protected int getServiceTime()
     {
    	 double rand = random.nextDouble();
    	 return (int)Math.round ((-mean_Service_Time*Math.log (1 - rand)));
     }
     
     protected int getArrivalTime()
     {
           double rand = random.nextDouble();
           return next_Arrival_Time + (int)Math.round ((-mean_Arrival_Time*Math.log (1 - rand)));
     } 
     
     
     public LinkedList<String> NextCar (int next_Arrival_Time)
     {
         final String BAD_TIME =
             "The time of the next arrival cannot be less than the current time.";
         if (next_Arrival_Time < current_Time)
              throw new IllegalArgumentException (BAD_TIME);
         while (next_Arrival_Time >= next_Departure_Time)
              Departure();
         return Arrival (next_Arrival_Time);
     } 

     protected LinkedList<String> Arrival (int next_Arrival_Time)
     {        
         final String ARRIVAL = "\tArrival";

         current_Time = next_Arrival_Time;         
         if (carQueue.size() == MAX_SIZE)        
         { 
             results.add (Integer.toString (current_Time) + ARRIVAL + Overflow);
             over_Flow_Count++;
         }
         else
         {
              results.add (Integer.toString (current_Time) + ARRIVAL);
              number_Of_Cars++;
              if (next_Departure_Time == max_Arrival_Time)  // if no car is being washed
                  next_Departure_Time = current_Time + getServiceTime();
              else
                  carQueue.add (new Car (next_Arrival_Time));
              results.add ("\n");
         } 
         return results;
     } 


     protected LinkedList<String> Departure()
     {
         final String DEPARTURE = "\tDeparture\t\t";
         int arrivalTime;
         current_Time = next_Departure_Time;
         results.add (Integer.toString (current_Time) + DEPARTURE +
                         Integer.toString (waiting_Time) + "\n");
         if (!carQueue.isEmpty())
         {
              Car car = carQueue.remove();
              arrivalTime = car.get_Arrival_Time();
              waiting_Time = current_Time - arrivalTime;
              sum_Of_Waiting_Times += waiting_Time;
              next_Departure_Time = current_Time + getServiceTime();
     
         } 
         else
         {
              waiting_Time = 0;
              next_Departure_Time = max_Arrival_Time; 
         } 
         return results;
     } 

     public LinkedList<String> finish()
     {
        
         while (!carQueue.isEmpty())  
               Departure();
         return results;
     } 


     public LinkedList<String> Results()
     {

         final String AVG_QUEUE =
        		 "\nAverage queue length is ";
         final String AVG_WAIT_TIME =
        		 "\nAverage waiting time is ";
         final String CAR_NULL = 
        		 "There were no cars in the car wash.\n";
         final String OVERFLOW =
        		 "\nThe number of overflows was ";
         if (number_Of_Cars == 0)
              results.add (CAR_NULL);
         else
         {
             	results.add (AVG_WAIT_TIME + Double.toString (
                          Math.round(( (double) sum_Of_Waiting_Times / number_Of_Cars) * 10 ) / 10.0) + " minutes per car.");
             	results.add (AVG_QUEUE + Double.toString (
                          Math.round(( (double) sum_Of_Waiting_Times / next_Departure_Time) * 10 ) / 10.0) + " cars per minute.");
             	results.add(OVERFLOW + over_Flow_Count + ".");
         }
         return results;
     } 

} 
