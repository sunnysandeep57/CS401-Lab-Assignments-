/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework8;

/**
 *
 * @author Itzsunnysandeep
 */

public class Car 
{
    protected int arrival_Time;


    public Car() { }  


    public Car (int next_Arrival_Time)
    {
        arrival_Time = next_Arrival_Time;
    } 


    public int get_Arrival_Time()
    {
        return arrival_Time;
    } 

} 
