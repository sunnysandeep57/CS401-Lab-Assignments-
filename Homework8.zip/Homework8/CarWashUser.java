/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework8;
import java.util.*;

public class CarWashUser
{
    public static void main (String[] args)
    {
        new CarWashUser().run();
    }
     
    public void run()
    {         
    	final String INPUT_PROMPT_1 = "\nPlease Enter mean Arrival Time: ";
    	final String INPUT_PROMPT_2 = "\nPlease Enter mean Service Time: ";
    	final String INPUT_PROMPT_3 = "\nPlease Enter maximum Arrival Time: ";
    	final String ERROR_MESS  = "\n ERROR!! Wrong Input ";
    	@SuppressWarnings("resource")
		Scanner sc = new Scanner (System.in);    
        int mean_Service_Time;
        int mean_Arrival_Time;
        int max_Arrival_Time;

        while (true)
        {
        	try
        	{
        		System.out.print (INPUT_PROMPT_1);
        		mean_Arrival_Time = sc.nextInt(); 
        		System.out.print (INPUT_PROMPT_2);
        		mean_Service_Time = sc.nextInt();
        		System.out.print (INPUT_PROMPT_3);
        		max_Arrival_Time = sc.nextInt(); 
        		
        		int ret = checkInput(mean_Arrival_Time, mean_Service_Time, max_Arrival_Time);
        		if(ret == 0)
        		{
        			CarWash carWash = new CarWash(mean_Arrival_Time, mean_Service_Time, max_Arrival_Time);
        			carWash.Process();
        			printResults(carWash);
        		}
        		else
        		{
        			System.out.print(ERROR_MESS);
        		}

        	}
	        catch (Exception e)
			{
			System.out.println(e);
			}
		}      
    }


    public int checkInput(int arrivalTime, int serviceTime, int max_Arrival_Time)
    {
    	return 0;
    }

    public void printResults (CarWash carWash)
    {
        LinkedList<String> results = carWash.Results();
        for (String s : results)
            System.out.print (s);
    } 

} 
