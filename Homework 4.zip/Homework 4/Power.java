package Homework4;

import java.lang.IllegalArgumentException;

public class Power {

	public Power() {
		// TODO Auto-generated constructor stub
	}
    
	
	public static long powerA(long i, int n) throws IllegalArgumentException {
		if(n == 0){
			return 1;
		}
		if(n < 0 || i >= Long.MAX_VALUE){
			throw new IllegalArgumentException();
		}
		
		return i * powerA(i, n-1);
	}
	
	public static long powerB(long i, int n) throws IllegalArgumentException {
		if(n == 0){
			return 1;
		}
		if(n < 0 || i >= Long.MAX_VALUE){
			throw new IllegalArgumentException();
		}
		Long output = 1L;
		for(int j = 0; j < n; j++){
			output *= i;
		}
		return output;
	}
	
	public static long powerC(long i, int n) throws IllegalArgumentException {
		
                if(n == 0){
			return 1;
		}
		if(n < 0 || i >= Long.MAX_VALUE){
			throw new IllegalArgumentException();
		}
		
		if(n % 2 == 0){
			return powerC(i * i, n/2);
		} else {
			return i * powerC(i * i, (n-1)/2);
		}
		
		
	}

	public static void main(String args[]){
            try{
                System.out.println(powerA(2L, 3));
		System.out.println(powerB(-5L, 0));
		System.out.println(powerC(2L, 5));
                System.out.println(powerC(-2L, 5));
                System.out.println(powerC(-2L, 4));
                System.out.println(powerC(10L, 11));
                System.out.println(powerC(5L, 2));
                System.out.println(powerB(5L, -2));
                
            }catch(IllegalArgumentException iae){
                iae.printStackTrace();
            }
        }
}
        
//        public static void main(String args[]){
//            System.out.println("New Test Scenarios: ");
//        PowerTest ptest = new PowerTest();
//        try{
//            ptest.test1();
//        }catch(Exception C){
//            System.out.print("Not Supported");
//            //C.printStackTrace();
//        } 
//        
//        }

