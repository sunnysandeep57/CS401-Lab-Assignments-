/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Homework4;

import java.util.Scanner;

/**
 *
 * @author sunnysandeep
 */
public class recursive {
    
    
    public static long jacobsthal(long number) {
    if ((number == 0) || (number == 1)) // base cases
      return number;
    else
      // recursion step
      return jacobsthal(number - 1) + 2*jacobsthal(number - 2);
  }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        final double NANO_FACTOR = 1000000000.0;
        long startTime, endTime, runTime;
        System.out.println("Enter the number of terms for Jacobsthal sequence : ");
        int noOfTerms = scanner.nextInt();
        startTime = System.nanoTime();
        
        for (int counter = 0; counter <= noOfTerms; counter++) {
            System.out.printf("jacobsthal of %d is: %d\n", counter, jacobsthal(counter));
        }
        endTime = System.nanoTime();
        runTime = endTime - startTime;
        System.out.println("\nThe Run time is : " + (runTime / NANO_FACTOR) + " seconds.");

    }
    
}
