/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Homework4;

/**
 *
 * @author Itzsunnysandeep
 */
public class smallest {
    public static double minimum(int[] A, int size)
    {   
      if(size == 1 )
      {
          return A[0];
      }
     double small =  minimum (A, size-1); 
     if (A[size-2] < small)
         return A[size-2];
     else
         return small;
    }
    public static void main(String args[])
    {
        int A[] = {10, -20, 1, 2, 0, 5, 100};
        double s = minimum(A,A.length);
        System.out.println("The smallest number in an array is : " +s);
    }
}
    
