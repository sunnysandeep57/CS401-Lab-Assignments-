package Homework4;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Time {

	public Time() {
		// TODO Auto-generated constructor stub
	}

	public static long powerA(long i, int n) throws IllegalArgumentException {
		if (n == 0) {
			return 1;
		}
		if (n < 0 || i >= Long.MAX_VALUE) {
			throw new IllegalArgumentException();
		}

		return i * powerA(i, n - 1);
	}

	public static long powerB(long i, int n) throws IllegalArgumentException {
		if (n == 0) {
			return 1;
		}
		if (n < 0 || i >= Long.MAX_VALUE) {
			throw new IllegalArgumentException();
		}
		Long output = 1L;
		for (int j = 0; j < n; j++) {
			output *= i;
		}
		return output;
	}

	public static long powerC(long i, int n) throws IllegalArgumentException {
		if (n == 0) {
			return 1;
		}
		if (n < 0 || i >= Long.MAX_VALUE) {
			throw new IllegalArgumentException();
		}

		if (n % 2 == 0) {
			return powerC(i * i, n / 2);
		} else {
			return i * powerC(i * i, (n - 1) / 2);
		}

	}

	public static long[] timer(long i, int maxN, String func) throws IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException {
		long[] timerValues = new long[maxN + 1];
		Object[] parameters = new Object[2];
		Class[] parameterTypes = new Class[2];
		parameterTypes[0] = long.class;
		parameterTypes[1] = int.class;
		Method method = Power.class.getMethod(func, parameterTypes);
		long timerValue = 0L;
		for (int j = 0; j <= maxN; j++) {
			parameters[0] = i;
			parameters[1] = j;
			timerValue = System.nanoTime();
			long x = (long) method.invoke(Power.class, parameters);
			timerValue = System.nanoTime() - timerValue;

			timerValues[j] = timerValue;
		}
		return timerValues;
	}

	public static void main(String args[]) throws IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException {

		long[] seriesA = timer(5L, 15, "powerA");
		System.out.println("----- \nRecursive Power\n-----");
		for (int i = 0; i < seriesA.length; i++) {
			System.out.println(i + " - " + seriesA[i]);
		}
                

		long[] seriesB = timer(5L, 15, "powerB");
		System.out.println("----- \nIterative Power\n-----");
		for (int i = 0; i < seriesB.length; i++) {
			System.out.println(i + " - " + seriesB[i]);
		}

		long[] seriesC = timer(5L, 15, "powerC");
		System.out.println("----- \n2nd Version Recursive Power\n-----");
		for (int i = 0; i < seriesC.length; i++) {
			System.out.println(i + " - " + seriesC[i]);
		}
	}
}
