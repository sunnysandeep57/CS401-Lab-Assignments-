/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Homework4;

import java.util.*;
import java.math.*;

/**
 *
 * @author sunnysandeep
 */
public class closedform {

    public static void main(String[] args) {
        int firstNumber = 0;
        int secondNumber = 1;
        int x = firstNumber;
        final double NANO_FACTOR = 1000000000.0;
        long startTime, endTime, runTime;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of terms for Jacobsthal sequence : ");

        int noOfTerms = scanner.nextInt();
        int nextNumber;
        startTime = System.nanoTime();
//        System.out.print(firstNumber + " " + secondNumber);

        for (int i = 0; i <= noOfTerms - 2; i++) {
//            int num1 = x;
//            int num2 = (1 + x) * (1 - 2 * (x));
//            nextNumber = (x / ((1 + x) * (1 - 2 * (x))));
//            System.out.print(" " + nextNumber);
//            firstNumber = secondNumber;
//            secondNumber = nextNumber;
                if(i % 2 == 0){
                    nextNumber = (((int) Math.pow(2, i)) - 1 )/ 3;
                }else{
                    nextNumber = (((int) Math.pow(2, i)) + 1 )/ 3;
                }
                
                System.out.println(nextNumber);
               // (Math.pow(2, i) - Math.pow('-1', i))
        }
        endTime = System.nanoTime();
        runTime = endTime - startTime;
        System.out.println("\nThe Run time is : " + (runTime / NANO_FACTOR) + " seconds.");

    }
}
