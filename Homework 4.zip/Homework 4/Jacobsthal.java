/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Homework4;

import java.util.Scanner;

/**
 *
 * @author sunnysandeep
 */
 
public class Jacobsthal {
 
    public static void main(String[] args) {
        
        int firstNumber = 0;
        int secondNumber = 1;
        final double NANO_FACTOR = 1000000000.0;
        long startTime, endTime, runTime;
        
                 
        Scanner scanner = new Scanner(System.in);
         
        System.out.println("Enter the number of terms for Jacobsthal sequence : ");
        
        
        int noOfTerms = scanner.nextInt();
        int nextNumber;
        startTime = System.nanoTime(); 
        System.out.print( firstNumber + " " + secondNumber);
         
        for(int i = 1; i <= noOfTerms - 2; i++) { 
             
            nextNumber = secondNumber + 2 * firstNumber;
            System.out.print(" " + nextNumber);
            firstNumber = secondNumber;
            secondNumber = nextNumber;
             
        }        
        endTime = System.nanoTime();
                runTime = endTime - startTime;
                System.out.println("\nThe Run time is : " + (runTime / NANO_FACTOR) + " seconds.");
    }
 
}
