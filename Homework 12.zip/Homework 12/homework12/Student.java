package homework12;



public class Student implements Comparable<Student> {

	  String fname;
	  String lname;
	  String mname;
	  long studentId;
	  
	  public Student (String lname,String fname,String mname,long studentId)
	  {
	    this.fname = fname;
	    this.lname = lname;
	    this.mname = mname;
	    this.studentId = studentId;
	  } // constructor
	  
	  public int compareTo (Student Student1)
	  {
	    //final double DELTA = 0.0000001;
                if(Student1 == null){
                    return 1;
                }
			
		    if (lname.compareTo (Student1.lname) < 0)
		        return -1;
		    if (lname.compareTo (Student1.lname) > 0)
		        return 1;
		    if (lname.compareTo (Student1.lname) == 0)
		    {
		    	if (fname.compareTo (Student1.fname) < 0)
		            return -1;
		    	else if (fname.compareTo (Student1.fname) > 0)
		            return 1;
		    	else if (fname.compareTo (Student1.fname) == 0)
		        {
		        	if (mname.compareTo (Student1.mname) < 0)
		                return -1;
		        	else if (mname.compareTo (Student1.mname) > 0)
		                return 1;
		            if (mname.compareTo (Student1.mname) == 0)
		            {
		            	 if (studentId < Student1.studentId )
		       		      return -1;
		       		    else if (studentId > Student1.studentId )
		       		      return 1;
		       		    else if (studentId == Student1.studentId )
		       		      return 0;
		       		    else return (Integer) null;
		            }
		        }
		    }
		    return 0;
	  }
	   
}




