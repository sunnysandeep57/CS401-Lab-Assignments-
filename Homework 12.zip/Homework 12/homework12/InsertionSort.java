package homework12;

public class InsertionSort {

	   public static <T extends Comparable> void insertionSort (T[] x)
	   {
	      for (int i = 1; i< x.length; i++)
	      {
	         T key = x[i];
	         int k = i;

	         //  Shift larger values to the right
	         while (k > 0 && key.compareTo(x[k-1]) < 0)
	         {
	            x[k] = x[k-1];
	            k--;
	         }//while
	            
	         x[k] = key;
	      }//for
	   }//insertion Sort method
}//Insertion Sort
