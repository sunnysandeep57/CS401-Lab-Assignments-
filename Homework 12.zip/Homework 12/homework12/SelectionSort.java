package homework12;

public class SelectionSort {
	   public static void selectionSort (Object [] x)
	   {
	      int pos;
	      Object temp;

	      for (int i = 0; i < x.length-1; i++)
	      {
	         pos = i;
	         for (int k = i+1; k < x.length; k++)
	            if (((Comparable) x[k]).compareTo(x[pos]) < 0)
	               pos = k;

	         // Swap the values
	         temp = (Object) x[pos];
	         x[pos] = x[i];
	         x[i] = temp;
	      }//for
	   }//Selection Sort method
	   
	
}//Selection Sort
