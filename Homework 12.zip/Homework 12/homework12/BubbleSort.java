package homework12;

public class BubbleSort {

	   public static void bubbleSort (Object[ ] x)
	   {
	   int finalSwapPos = x.length - 1,
	   swapPos;
	   Object temp;
	   while (finalSwapPos > 0)
	   {
	   swapPos = 0;
	   for (int i = 0; i < finalSwapPos; i++)
	   if (((Comparable)x[i]).compareTo(x[i+1])>0 )
	   {
		   temp = (Object) x[i];
	         x[i] = x[i+1];
	         x[i+1] = temp;
	   swapPos = i;
	   } // if
	   finalSwapPos = swapPos;
	   } // while
	   } // bubbleSort method
	   
}//Bubble Sort
