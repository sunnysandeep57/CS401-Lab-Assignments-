package homework12;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Scanner;

public class Sorts {

	public static void main(String[] args) throws IOException {
//                String filePath = "/Users/sunnysandeep/Downloads/students-64000.dat";
                String filePath = "/Users/sunnysandeep/Desktop/Courses/Java/CS401/HW11/Question 1/students-64000.dat";
                File f = new File(filePath);

		String readLine;
		String[] readLineSplited;

		LineNumberReader lnr = new LineNumberReader(new FileReader(new File(filePath)));
		lnr.skip(Long.MAX_VALUE);
		//System.out.println(lnr.getLineNumber() + 1); 
		lnr.close();
		int i = 0, j = 0, k = 0;
		Student[] student2 = new Student[lnr.getLineNumber() + 1];
		Student[] student3 = new Student[lnr.getLineNumber() + 1];
		Student[] student4 = new Student[lnr.getLineNumber() + 1];
		
		// Reading for Bubble Sort
		Scanner scan2 = new Scanner(f);
		long startTime2 = System.nanoTime();
		while (scan2.hasNextLine()) {
			readLine = scan2.nextLine();
			readLineSplited = readLine.split(" ");
			Student student1 = new Student(readLineSplited[0],
					readLineSplited[1], readLineSplited[2],
					Long.parseLong(readLineSplited[3]));
			student4[k++] = student1;
		}
		BubbleSort.bubbleSort(student4);
		// System.out.println(Arrays.toString(student2));
		long elapsedTime2 = System.nanoTime() - startTime2;
		double seconds2 = (double) elapsedTime2 / 1000000000.0;
		System.out.println("Bubble sort of data file takes " + (seconds2)
				+ " seconds");
		// System.out.println(""+stude);
                student4 = null;
		scan2.close();

		// Reading for Insertion Sort
		Scanner scan1 = new Scanner(f);
		long startTime1 = System.nanoTime();
		while (scan1.hasNextLine()) {
			readLine = scan1.nextLine();
			readLineSplited = readLine.split(" ");
			Student student1 = new Student(readLineSplited[0],
					readLineSplited[1], readLineSplited[2],
					Long.parseLong(readLineSplited[3]));
			student3[j++] = student1;
		}
		InsertionSort.insertionSort(student3);
		// System.out.println(Arrays.toString(student2));
		long elapsedTime1 = System.nanoTime() - startTime1;
		double seconds1 = (double) elapsedTime1 / 1000000000.0;
		System.out.println("Insertion sort of data file takes " + (seconds1)
				+ " seconds");
		// System.out.println(""+stude);
                student3 = null;
		scan1.close();

		// Reading for Selection Sort
		Scanner scan = new Scanner(f);
		long startTime = System.nanoTime();
		while (scan.hasNextLine()) {
			readLine = scan.nextLine();
			readLineSplited = readLine.split(" ");
			Student student1 = new Student(readLineSplited[0],
					readLineSplited[1], readLineSplited[2],
					Long.parseLong(readLineSplited[3]));
			student2[i++] = student1;
		}
		SelectionSort.selectionSort(student2);
		// System.out.println(Arrays.toString(student2));
		long elapsedTime = System.nanoTime() - startTime;
		double seconds = (double) elapsedTime / 1000000000.0;
		System.out.println("Selection sort of data file takes " + (seconds)
				+ " seconds");
		// System.out.println(""+stude);
                student2 = null;
		scan.close();

	}

}
