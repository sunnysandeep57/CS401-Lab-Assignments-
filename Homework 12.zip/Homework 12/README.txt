Comparision with ID alone takes lesser time to sort the records .It's because for the function B there is only 
comparision i.e ID and for function A we have compare the first,last and middle names if the names are same we 
have to use ID as the sort field.So,the function A takes more time to sort when compared to function B.
