package homework122;

import homework122.*;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Scanner;

public class Sorts {

	public static void main(String[] args) throws IOException {
		String filePath = "/Users/sunnysandeep/Desktop/Courses/Java/CS401/HW11/Question 1/students-64000.dat";
		File f = new File(filePath);

		String readLine;
		String[] readLineSplited;
		HeapSort<Student> ai = new HeapSort<Student>();
		LineNumberReader lnr = new LineNumberReader(new FileReader(new File(
				filePath)));
		lnr.skip(Long.MAX_VALUE);
		// System.out.println(lnr.getLineNumber() + 1);
		lnr.close();
		int i = 0, j = 0, k = 0;
		Student[] student4 = new Student[lnr.getLineNumber() + 1];
		Student[] student2 = new Student[lnr.getLineNumber() + 1];
		Student[] student3 = new Student[lnr.getLineNumber() + 1];

		// OR
		// Student [] student2= new Student[3380];
		// Student [] student3= new Student[3380];
		// Student [] student4= new Student[3380];

		// Reading for Heap Sort
		Scanner scan = new Scanner(f);
		while (scan.hasNextLine()) {
			readLine = scan.nextLine();
			readLineSplited = readLine.split(" ");
			Student student6 = new Student(readLineSplited[0],
					readLineSplited[1], readLineSplited[2],
					Long.parseLong(readLineSplited[3]));
			student2[i++] = student6;
		}
		long startTime = System.nanoTime();
		ai.heapSort(student2);
		// System.out.println(Arrays.toString(student2));
		long elapsedTime = System.nanoTime() - startTime;
		double seconds = (double) elapsedTime / 1000000000.0;
		System.out.println("Heap sort of data file takes " + (seconds)
				+ " seconds");
		// System.out.println(""+stude);
		scan.close();

		// Reading for Quick Sort
		Scanner scan1 = new Scanner(f);
		while (scan1.hasNextLine()) {
			readLine = scan1.nextLine();
			readLineSplited = readLine.split(" ");
			Student student1 = new Student(readLineSplited[0],
					readLineSplited[1], readLineSplited[2],
					Long.parseLong(readLineSplited[3]));
			student3[j++] = student1;
		}
		long startTime1 = System.nanoTime();
		CS401QSort.quicksort(student3, 0, student3.length - 1);
		// System.out.println(Arrays.toString(student2));
		long elapsedTime1 = System.nanoTime() - startTime1;
		double seconds1 = (double) elapsedTime1 / 1000000000.0;
		System.out.println("Quick sort of data file takes " + (seconds1)
				+ " seconds");
		// System.out.println(""+stude);
		scan1.close();

		// Reading for Merge Sort
		Scanner scan2 = new Scanner(f);
		while (scan2.hasNextLine()) {
			readLine = scan2.nextLine();
			readLineSplited = readLine.split(" ");
			Student student5 = new Student(readLineSplited[0],
					readLineSplited[1], readLineSplited[2],
					Long.parseLong(readLineSplited[3]));
			student4[k++] = student5;
		}
		long startTime2 = System.nanoTime();
		MergeSort.sort(student4);
		// System.out.println(Arrays.toString(student2));
		long elapsedTime2 = System.nanoTime() - startTime2;
		double seconds2 = (double) elapsedTime2 / 1000000000.0;
		System.out.println("Merge sort of data file takes " + (seconds2)
				+ " seconds");
		// System.out.println(""+stude);
		scan2.close();

	}

}
