package homework122;

import homework12.*;


public class HeapSort<E> {
	
	private transient Object[ ] queue;
	private int size = 0;

	public  void heapSort (Object[ ] a)
	{
	 queue = a;
	
	int length = queue.length;
	size = length;
	// Convert queue into a heap:
	for (int i = (size >> 1) - 1; i >= 0; i--)
	siftDown (i, (E)queue [i]);
	// Sort queue into reverse order:
	E x;
	for (int i = 0; i < length; i++)
	{
	x = (E)queue [--size];
	queue [size] = queue [0];
	siftDown (0, x);
	} // sort queue into reverse order
	// Reverse queue:
	for (int i = 0; i < length / 2; i++)
	{
	x = (E)queue [i];
	queue [i] = queue [length - i - 1];
	queue [length - i - 1] = x;
	} // reverse queue
	} // method heapSort
	

	private void siftDown(int k, E x) {
		// TODO Auto-generated method stub
		
				siftDownComparable(k, x);
	}

	private void siftDownComparable(int k, E x) {
		// TODO Auto-generated method stub
		Comparable<? super E> key = (Comparable<? super E>)x;
		int half = size >>> 1; // loop while a non-leaf
		while (k < half) {
		int child = (k << 1) + 1; // assume left child is least
		Object c = queue[child];
		int right = child + 1;
		if (right < size &&
		((Comparable<? super E>) c).compareTo((E) queue[right]) > 0)
		c = queue[child = right];
		if (key.compareTo((E) c) <= 0)
		break;
		queue[k] = c;
		k = child;
		}
		queue[k] = key;
	}
}
