package homework122;

import homework12.*;


public class CS401QSort
{
   public static void quicksort(Object a[], int left, int right)
   {
      if (left < right)
      {
          int pi = (left+right)/2;
          int newPivotIndex = partition(a, left, right, pi);
          quicksort(a, left, newPivotIndex-1);
          quicksort(a, newPivotIndex+1, right);
      }
   }

   public static int partition(Object a[], int left, int right, int pivotIndex)
   {
      Object pivot;
      Object tmp;
	int i, storeIndex;

      pivot = a[pivotIndex];

      tmp = a[pivotIndex];       /* Swap a[pivotIndex] and a[right] */
      a[pivotIndex] = a[right];
      a[right] = tmp;

     storeIndex = left;
     for (i = left; i < right && ((Comparable) a[i]).compareTo(pivot) < 0; i++ )
     {
        {
           tmp = a[storeIndex];       /* Swap a[i] and a[storeIndex] */
           a[storeIndex] = a[i];
           a[i] = tmp;
    
           storeIndex++;
        }
     }

     tmp = a[right];                /* Swap a[storeIndex] and a[right] */
     a[right] = a[storeIndex];      /* Moves pivot to its final place */
     a[storeIndex] = tmp;

     return storeIndex;
   }
}
