package homework122;

import homework122.*;



public class Student implements Comparable<Student> {

	  String fname;
	  String lname;
	  String mname;
	  long studentId;
	  
	  public Student (String lname,String fname,String mname,long studentId)
	  {
	    this.fname = fname;
	    this.lname = lname;
	    this.mname = mname;
	    this.studentId = studentId;
	  } // constructor
	 
          
          public int compareTo (Student Student1)
	  {
	    //final double DELTA = 0.0000001;
	    
			
		   
		            	 if (studentId < Student1.studentId )
		       		      return -1;
		       		    else if (studentId > Student1.studentId )
		       		      return 1;
		       		    else if (studentId == Student1.studentId )
		       		      return 0;
		       		    else return (Integer) null;
		            }
		
	  }
	   




