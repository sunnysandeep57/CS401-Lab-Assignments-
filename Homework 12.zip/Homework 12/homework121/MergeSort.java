package homework121;

public class MergeSort {


	/**
	 * Sorts a specified array of objects according to the compareTo method in
	 * the specified class of elements. The worstTime(n) is O(n log n).
	 *
	 * @param a
	 *            - the array of objects to be sorted.
	 *
	 */
	public static void sort(Object[] a) {
		Object aux[] = (Object[]) a.clone();
		mergeSort(aux, a, 0, a.length);
	}

	/**
	 * Sorts, by the Comparable interface, a specified range of a specified
	 * array into the same range of another specified array. The worstTime(k) is
	 * O(k log k), where k is the size of the subarray.
	 *
	 * @param src
	 *            � the specified array whose elements are to be sorted into
	 *            another specified array.
	 * @param dest
	 *            � the specified array whose subarray is to be sorted.
	 * @param low
	 *            � the smallest index in the range to be sorted.
	 * @param high
	 *            � 1 + the largest index in the range to be sorted.
	 *
	 */
	private static void mergeSort(Object src[], Object dest[], int low, int high) {
		int length = high - low;
		// Use Insertion Sort for small subarrays.
		if (length < 7) {
			for (int i = low; i < high; i++)
				for (int j = i; j > low
						&& ((Comparable) dest[j - 1]).compareTo(dest[j]) > 0; j--)
					swap(dest, j, j - 1);
			return;
		} // if length < 7
			// Sort left and right halves of src into dest.
		int mid = (low + high) >> 1; // >> 1 has same effect as / 2, but is
										// faster
		mergeSort(dest, src, low, mid);
		mergeSort(dest, src, mid, high);
		// If left subarray less than right subarray, copy src to dest.
		if (((Comparable) src[mid - 1]).compareTo(src[mid]) <= 0) {
			System.arraycopy(src, low, dest, low, length);
			return;
		}
		// Merge sorted subarrays in src into dest.
		for (int i = low, p = low, q = mid; i < high; i++)
			if (q >= high
					|| (p < mid && ((Comparable) src[p]).compareTo(src[q]) <= 0))
				dest[i] = src[p++];
			else
				dest[i] = src[q++];
	}

	/**
	 * Swaps two specified elements in a specified array.
	 *
	 * @param dest
	 *            - the array in which the two elements are to be swapped.
	 * @param a
	 *            - the index of one of the elements to be swapped.
	 * @param b
	 *            - the index of the other element to be swapped.
	 *
	 */
	public static void swap(Object[] dest, int a, int b) {
		Object t = dest[a];
		dest[a] = dest[b];
		dest[b] = t;
	} // method swap
}
