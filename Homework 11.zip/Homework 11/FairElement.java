/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework11;

import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FairElement<E>
{  
  E element;
  
  long count;
  
  
  public FairElement (E element, long count)
  {  
    this.element = element;
    this.count = count;    
  } // constructor
  
  @Override
  public String toString() {
    return element.toString();
  }
    
} // class FairElement
