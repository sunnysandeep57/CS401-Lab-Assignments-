/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework11;

public class HuffmanEncoding {

	public static void main(String args[]) {
		run_example_1();
		run_example_2();
		run_example_3();
		run_example_4();
	}

	public static void run_example_1() {
		System.out.println("Encoded string for hello world :");
		byte a = 0b01111001;
		byte b = 0b01011101;
		byte c = 0b00011110;
		byte d = 0b00101101;
		System.out.println((char) a + "" + (char) b + "" + (char) c + "" + (char) d);
	}
	
	
	public static void run_example_2() {
		
		System.out.println("Encoded string for a man a plan panama :");
		byte a = 0b01111011;
        byte b = 0b01101110;
        byte c = (byte) 0b11110010;
        byte d = (byte) 0b10011011;
        byte e = (byte) 0b11000110;
        byte f = 0b01011000;
        System.out.println((char)a +""+ (char)b+""+(char)c+""+(char)d+""+(char)e+""+(char)f);
	}

	public static void run_example_3() {
		System.out.println("Encoded string for sign sings singe :");
		byte a = (byte) 0b10110011;
		byte b = (byte) 0b11001101;
		byte c = (byte) 0b10111011;
		byte d = 0b00011011;
		byte e = 0b01110100;
		byte f = 0b00000000;
		System.out.println((char) a + "" + (char) b + "" + (char) c + "" + (char) d + "" + (char) e + "" + (char) f);
	}

	public static void run_example_4() {
		System.out.println("Encoded string for right write wright :");
		byte a = (byte) 0b11111010;
		byte b = (byte) 0b11011000;
		byte c = (byte) 0b10100111;
		byte d = (byte) 0b11000101;
		byte e = (byte) 0b00101001;
		byte f = (byte) 0b11110101;
		byte g = (byte) 0b10110000;
		System.out.println((char) a + "" + (char) b + "" + (char) c + "" + (char) d + "" + (char) e + "" + (char) f + ""
				+ (char) g);
	}

}
