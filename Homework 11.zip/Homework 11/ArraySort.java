package homework11;
import java.util.Arrays;
import java.util.Collections;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

 
@SuppressWarnings("unused")
public class ArraySort {
 
	public static void main(String[] args) {
 
		// example of an array in java
		String[] arrayString = new String[] {"a1", "a10", "a20", "a2"};
		FairPQ<Integer> pq = new FairPQ<Integer>();
		System.out.println("Printing the initial contents");
		for(String s:arrayString){
			System.out.println(s);
		}
		//Sorting the array in natural order
		Arrays.sort(arrayString);
		System.out.println("Printing the sorted array in ascending order");
		for(String s:arrayString){
			System.out.println(s);
		}

	}
 
}
