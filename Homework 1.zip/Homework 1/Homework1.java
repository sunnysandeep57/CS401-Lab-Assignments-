/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Homework1;

import java.lang.*;
import java.util.*;
import java.io.*;

/**
 * @author sunnysandeep Write a simple java program to measure fuel economy
 */
//import java.*;
public class Homework1 {
    
//    public static String ReadString() {
//        try {
//            InputStreamReader input = new InputStreamReader(System.in);
//            BufferedReader reader = new BufferedReader(input);
//            return reader.readLine();
//        } catch (Exception e) {
//
//            e.printStackTrace();
//            return "";
//        }
//    }

    /**
     *
     * @return
     */

    public static double ReadInteger() {
        try {
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
            return Double.parseDouble(reader.readLine());
        } catch (Exception e) {

            e.printStackTrace();
            return 0;
        }
    }

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        int option;
        double a, b;
        System.out.println("=========Program to measure Fuel economy=========\n");
        while (true) {
            //User will input his choice
            System.out.print("Enter Your Choice: 1 - MPG, 2 - KPG, 3 - GPH: ");
            option = (int) ReadInteger();
            if (option < 1 || option > 3) {
                return;
            }
            //Switch case runs based on the option that is given by the user as a input
            switch (option) {

                //Program to find the Average MPG
                case 1:
                    System.out.print("Enter no.of Miles:");
                    a = ReadInteger();
                    System.out.print("Fuel Consumed in Gallons:");
                    b = ReadInteger();
                    System.out.print("Average MPG : ");
                    System.out.println(((float) a) / b);
                    break;
                    
                //Program to find the Average KPL    
                case 2:
                    System.out.print("Enter no.of KIlometers:");
                    a = ReadInteger();
                    System.out.print("Fuel Consumed in Liter:");
                    b = ReadInteger();
                    System.out.print("Average KPL : ");
                    System.out.println(((float) a) / b);
                    break;
                    
                //Program to find the Average GPH    
                case 3:
                    System.out.print("Enter no.of Gallons:");
                    a = ReadInteger();
                    System.out.print("Enter no.of hours:");
                    b = ReadInteger();
                    System.out.print("Average GPH : ");
                    System.out.println(((float) a) / b);
                    break;

                default:
                    break;
            }
        }
    }
}
