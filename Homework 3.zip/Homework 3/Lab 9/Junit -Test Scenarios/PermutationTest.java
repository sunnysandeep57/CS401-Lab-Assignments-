package Homework3;

import static org.junit.Assert.*;

import org.junit.Test;

public class PermutationTest {

    @Test
    public void test_permute1() {
        System.out.println("To check the peremutation for 5862");

        String a = Permutation.permute("5862");
        String b = Permutation.permute("5862");
        assertTrue(b.equals(a));
        System.out.println("Permutation for 5862 is \n" + a);
    }

    @Test
    public void test_permute2() {
        System.out.println("To check the peremutation for xyz");

        String a = Permutation.permute("xyz");
        String b = Permutation.permute("xyz");
        assertTrue(b.equals(a));
        System.out.println("Permutation for xyz is \n" + a);
    }

    @Test
    public void test_permute3() {
        System.out.println("To check the peremutation for bcbc");

        String a = Permutation.permute("bcbc");
        String b = Permutation.permute("bcbc");
        assertTrue(b.equals(a));
        System.out.println("Permutation for bcbc is \n" + a);
    }

    @Test
    public void test_permute4() {
        System.out.println("To check the peremutation for 12xy");

        String a = Permutation.permute("12xy");
        String b = Permutation.permute("12xy");
        assertTrue(b.equals(a));
        System.out.println("Permutation for 12xy is \n" + a);
    }

//    @Test
//    public void test_permute5() {
//        System.out.println("To check the peremutation for +*89");
//
//        String a = Permutation.permute("+*89");
//        String b = Permutation.permute("+*89");
//        assertTrue(b.equals(a));
//        System.out.println("Permutation for +*89 is \n" + a);
//    }

}
