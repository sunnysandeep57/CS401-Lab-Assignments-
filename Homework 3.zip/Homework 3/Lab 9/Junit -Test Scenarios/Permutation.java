/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Homework3;

/**
 *
 * @author Itzsunnysandeep
 */
import java.util.*;

import javax.sound.midi.Synthesizer;
import Homework3.PermutationTest;

public class Permutation {

    public static void main(String[] args) {
//        new Permutation().perm();
        System.out.println("New Test Scenarios: ");
        PermutationTest ptest = new PermutationTest();
        ptest.test_permute1();
        ptest.test_permute2();
        ptest.test_permute3();
        ptest.test_permute4();
        //ptest.test_permute5();
        
    } // method main

    /**
     * Permutation calculation for the string
     */
    public void perm() {
        final String EXIT = "+++";
        String line;
        Scanner sc = new Scanner(System.in);

        while (true) {
            try {
                System.out.print("\nEnter a string (or " + EXIT + " to quit): ");
                line = sc.nextLine();
                if (line.equals(EXIT)) {
                    break;
                }
                System.out.println(permute(line));
            }//try
            catch (Exception e) {
                System.out.println(e);
            }//catch Exception
        }//while
    } // method run

    public static String permute(String string) {
        StringBuffer buf = new StringBuffer(string);
        return recursion(buf, 0);
    }

    protected static String recPermute(char[] c, int startChar) {
        if (startChar == c.length - 1) {
            return String.valueOf(c) + "\n";
        } else {
            String perm = new String();
            char temp;
            for (int i = startChar; i < c.length; i++) {
                temp = c[i];
                c[i] = c[startChar];
                c[startChar] = temp;
                perm = perm + recPermute(String.valueOf(c).toCharArray(), startChar + 1);
            } // for
            return perm;
        } // else
    } // method recPermute

    protected static String recursion(StringBuffer buf, int value) {
        if (value == buf.length() - 1) {
            return String.valueOf(buf) + "\n";
        } else {
            String perm = new String();

            for (int i = value; i < buf.length(); i++) {
                char t = buf.charAt(i);
                buf.setCharAt(i, buf.charAt(value));
                buf.setCharAt(value, t);
                perm = perm + recursion(buf, value + 1);
                char u = buf.charAt(value);
                buf.setCharAt(value, buf.charAt(i));
                buf.setCharAt(i, u);
            }
            return perm;
        }
    } // method recursion

} // class Permutation

