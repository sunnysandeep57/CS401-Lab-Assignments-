/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Itzsunnysandeep
 */
package Homework3;

import static java.time.Clock.system;
import java.util.*;

public class FibonacciUser {

    private static String ERROR_MESSAGE;

    public static void main(String[] args) {
        new FibonacciUser().run();

    } // method main

    private static Exception IllegalArgumentException(String ERROR_MESSAGE) {
        throw new UnsupportedOperationException("The number entered must be greater than 0 and at most 92" ); 
    } // Exception Message

    /**
     * The Fibonacci number of the integer entered has been printed.
     */
    public void run() {
        final double NANO_FACTOR = 1000000000.0;
        long startTime, endTime, runTime;
        startTime = System.nanoTime();
        Scanner sc = new Scanner(System.in);
        int n,exit = -1;
        while (true) {
            try {
                System.out.print("\n\nPlease enter the positive integer for Fibonacci series (or) " +exit+ " to quit:");
                System.out.print("");
                n = sc.nextInt();
                if (n == -1) {
                    break;
                }
                System.out.println("\nFibonacci value is : " + fib1(n, 1, 1));
                endTime = System.nanoTime();
                runTime = endTime - startTime;
                System.out.println("\nThe Run time is : " + (runTime / NANO_FACTOR) + " seconds.");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }

    public static long fib(int n) throws Exception {
        final int maxValue = 92;
        long previous, current, temp;
        if (n <= 0 || n >= maxValue+1) {
            throw IllegalArgumentException(ERROR_MESSAGE);
        }
        if (n <= 2) {
            return 1;
        }
        previous = 1;
        current = 1;
        //Assign the previous and current values to 1 and perform the calculations for the next series and will be done by the below for loop
        for (int i = 3; i <= n; i++) {
            temp = current;
            current = current + previous;
            previous = temp;
        } 
        return current;
    }

    public static long fib1(int n, long previous, long current) throws Exception {
        final int maxValue = 92;
        if (n <= 0 || n >= maxValue+1) {
            throw IllegalArgumentException(ERROR_MESSAGE);
        }
        long temp;
        if (n <= 2) {
            return current;
        } 
        else {
            temp = current;
        }
        current = current + previous;
        previous = temp;
        System.out.println("cur " + current + " , " + "prev " + previous + " fibval " + n);
        return fib1(n - 1, previous, current);
    }

    public static long fib2(int n) throws Exception {
        final int maxValue = 92;
        if (n <= 0 || n >= maxValue+1) {
            throw IllegalArgumentException(ERROR_MESSAGE);
        }
        return (long) ((1 / Math.sqrt(5)) * (Math.pow((1 + Math.sqrt(5)) / 2, n)
                - Math.pow((1 - Math.sqrt(5)) / 2, n)));
    } 
    
    public static long fib3(int n) throws Exception {
        final int maxValue = 92;
        if (n <= 2) {
            return 1;
        }
        if (n <= 0 || n >= maxValue+1) {
            throw new Exception(ERROR_MESSAGE);
        }
        return fib3(n - 1) + fib3(n - 2);
    }
}
