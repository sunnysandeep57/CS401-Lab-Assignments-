/**
 * 
 */
package homework10;

import java.io.*;

import homework9.CS401BSTExample;

public class Lab10Shell  {

   public static void main(String[] args) throws java.io.IOException {
	   
	   
		    new CS401PriorityQueue().maxHeap();
		  // method main
		  
		  
      String commandLine;
      BufferedReader console = new BufferedReader
                               (new InputStreamReader(System.in));
	 
      // Break out with <control><C> or "quit"
      while (true) {
         // Prompt and read what the user entered
         System.out.print("lab10> ");
         commandLine = console.readLine();
	 if (commandLine.equals("quit"))  {
             break; 
         }
         // if the user entered a return, just loop again
         if (commandLine.equals(""))  {
	    continue;
         }

         // Else, commandLine contains Type elem1 elem2 elem3 elem4
         // where Type is one of Integer, String, or Float and 
         // elem1, elem2, ... are the objects to be stored on the max
         // heap.
      }
   }
   
   
   public void maxHeap()  {
	     run_example_1();
	    // run_example_2();
	   }
   
   
   public void run_example_1()
   {
       System.out.println("The Max Heap is ");
       CS401PriorityQueue<Integer> pq = new CS401PriorityQueue<Integer>();
       MaxHeap maxHeap = new MaxHeap(15);
       maxHeap.insert(5);
       maxHeap.insert(3);
       maxHeap.insert(17);
       maxHeap.insert(10);
       maxHeap.insert(84);
       maxHeap.insert(19);
       maxHeap.insert(6);
       maxHeap.insert(22);
       maxHeap.insert(9);
       maxHeap.maxHeap();

       maxHeap.print();
       System.out.println("The max val is " + maxHeap.remove());
   }
}
