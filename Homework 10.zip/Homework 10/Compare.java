package homework10;

import java.io.*;
import java.util.*;

import homework10.BinarySearchTree.Entry;

public class Compare {
	
	
public static void main (String[] args) throws IOException{
		
	CS401LinkedListImpl<Student> LinkedList = new CS401LinkedListImpl<Student>();
		BinarySearchTree<Student> StudentBST = new BinarySearchTree<Student>(); 
		
		File f = new File("/Users/sunnysandeep/Downloads/students-64000.dat");
		
		String readLine;
		String[] readLineSplited;
		Scanner scan = new Scanner(f);
		
		
		//Reading for Linked List
		long startTime = System.nanoTime();
		while(scan.hasNextLine()){	
			readLine = scan.nextLine();
			readLineSplited= readLine.split(" ");
			Student student1 = new Student(readLineSplited[0] , readLineSplited[1], Long.parseLong(readLineSplited[3])); 
			LinkedList.add(student1);
		}
		long elepsedTime = System.nanoTime() - startTime; 
		double seconds = (double)elepsedTime / 1000000.0;
		System.out.println("Time taken to load the records in a linked list: "+ (seconds) +" miliseconds");
		//System.out.println("Size : "+LinkedList.size());
		scan.close();
		
	
		
		//reading for binary search tree
		Scanner scan3 = new Scanner(f);
		long startTime3 = System.nanoTime();
		while(scan3.hasNextLine()){	
			readLine = scan3.nextLine();
			readLineSplited= readLine.split(" ");
			Student student1 = new Student(readLineSplited[0] , readLineSplited[1], Long.parseLong(readLineSplited[3])); 
			StudentBST.add(student1);
		}
		long elepsedTime3 = System.nanoTime() - startTime3; 
		seconds = (double)elepsedTime3 / 1000000.0;
		System.out.println("Time taken to load the records in a binary search tree : "+ (seconds) +" miliseconds");
		//System.out.println("Size : "+ StudentBST.size);
		
		scan3.close();	
		
		
		System.out.println("\n\n");
		System.out.println("Searching for student ID 483293267");
		Student s1 = new Student(null, null, 483293267);
		Student temp = null;
		startTime = System.nanoTime();
		for(Student k : LinkedList){
			if(k.studentId == s1.studentId)
				temp =k;
		}
		if(temp==null){
			System.out.println("No record with this key found, Student not found");
		}else
			System.out.println("Success (record found): "+temp.lname+ "  " + temp.fname + "  " + temp.studentId);
		elepsedTime = System.nanoTime() - startTime;
		seconds = (double)elepsedTime / 1000000.0;
		System.out.println("Searching time in a random linked list : "+ (seconds) +" miliseconds");
		
		
		
		startTime = System.nanoTime();
		Entry<Student> sResult = StudentBST.getEntry(s1);
		elepsedTime = System.nanoTime() - startTime;
		seconds = (double)elepsedTime / 1000000.0;
		System.out.println("Searching time in a binary search tree : "+ (seconds) +" miliseconds");
		
		
		System.out.println("\n\n");
		System.out.println("Searching for student ID 1902997270");
		s1 = new Student(null, null, 1902997270);
		temp = null;
		startTime = System.nanoTime();
		for(Student i : LinkedList){
			if(i.studentId == s1.studentId)
				temp =i;
		}
		if(temp==null){
			System.out.println("No record with this key found, Student not found");
		}else
			System.out.println("Success (record found): "+temp.lname+ "  " + temp.fname + "  " +temp.studentId);
		elepsedTime = System.nanoTime() - startTime;
		seconds = (double)elepsedTime / 1000000.0;
		System.out.println("Searching time in a random linked list : "+ (seconds) +" miliseconds");
		
		
		
		
		
		startTime = System.nanoTime();
		sResult = StudentBST.getEntry(s1);
		elepsedTime = System.nanoTime() - startTime;
		seconds = (double)elepsedTime / 1000000.0;
		System.out.println("Searching time in a binary search tree : "+ (seconds) +" miliseconds");
		
		System.out.println("\n\n");
		System.out.println("Searching for student ID 856408684");
		s1 = new Student(null, null, 856408684);
		temp = null;
		startTime = System.nanoTime();
		for(Student i : LinkedList){
			if(i.studentId == s1.studentId)
				temp =i;
		}
		if(temp==null){
			System.out.println("No record with this key found, Student not found");
		}else
			System.out.println("Success (record found): "+temp.lname+ "  " + temp.fname + "  " +temp.studentId);
		elepsedTime = System.nanoTime() - startTime;
		seconds = (double)elepsedTime / 1000000.0;
		System.out.println("Searching time in a random linked list : "+ (seconds) +" miliseconds");
		
		//*********************************************************************************************
		startTime = System.nanoTime();
		sResult = StudentBST.getEntry(s1);
		elepsedTime = System.nanoTime() - startTime;
		seconds = (double)elepsedTime / 1000000.0;
		System.out.println("Searching time in a binary search tree : "+ (seconds) +" miliseconds");  
		
		//*********************************************************************************************
                
                System.out.println("\n\n");
		System.out.println("Searching for student ID 143507366");
		s1 = new Student(null, null, 143507366);
		temp = null;
		startTime = System.nanoTime();
		for(Student i : LinkedList){
			if(i.studentId == s1.studentId)
				temp =i;
		}
		if(temp==null){
			System.out.println("No record with this key found, Student not found");
		}else
			System.out.println("Success (record found): "+temp.lname+ "  " + temp.fname + "  " +temp.studentId);
		elepsedTime = System.nanoTime() - startTime;
		seconds = (double)elepsedTime / 1000000.0;
		System.out.println("Searching time in a random linked list : "+ (seconds) +" miliseconds");
                
		//*********************************************************************************************
				startTime = System.nanoTime();
				sResult = StudentBST.getEntry(s1);
				elepsedTime = System.nanoTime() - startTime;
				seconds = (double)elepsedTime / 1000000.0;
				System.out.println("Searching time in a binary search tree : "+ (seconds) +" miliseconds");  
				
		//*********************************************************************************************        
                
                System.out.println("\n\n");
		System.out.println("Searching for student ID 307954472");
		s1 = new Student(null, null, 307954472);
		temp = null;
		startTime = System.nanoTime();
		for(Student i : LinkedList){
			if(i.studentId == s1.studentId)
				temp =i;
		}
		if(temp==null){
			System.out.println("No record with this key found, Student not found");
		}else
			System.out.println("Success (record found): "+temp.lname+ "  " + temp.fname + "  " +temp.studentId);
		elepsedTime = System.nanoTime() - startTime;
		seconds = (double)elepsedTime / 1000000.0;
		System.out.println("Searching time in a random linked list : "+ (seconds) +" miliseconds");
                
                
		
		
		
		startTime = System.nanoTime();
		sResult = StudentBST.getEntry(s1);
		if(sResult==null){
			System.out.println("No record with this key found, Student not found");
		}else		
		elepsedTime = System.nanoTime() - startTime;
		seconds = (double)elepsedTime / 1000000.0;
		System.out.println("Searching time in a binary search tree : "+ (seconds) +" miliseconds");

		
		
		
		
		System.out.println("\n\n");
		System.out.println("Searching for student ID 876561221");
		s1 = new Student(null, null, 876561221);
		temp = null;
		startTime = System.nanoTime();
		for(Student i : LinkedList){
			if(i.studentId == s1.studentId)
				temp =i;
		}
		if(temp==null){
			System.out.println("No record with this key found, Student not found");
		}else
			System.out.println("Success (record found):"+temp.lname+ "  " + temp.fname + "  " +temp.studentId);
		elepsedTime = System.nanoTime() - startTime;
		seconds = (double)elepsedTime / 1000000.0;
		System.out.println("Searching time in a random linked list : "+ (seconds) +" miliseconds");
		
		
		
		
		startTime = System.nanoTime();
		sResult = StudentBST.getEntry(s1);
			
		elepsedTime = System.nanoTime() - startTime;
		seconds = (double)elepsedTime / 1000000.0;
		System.out.println("Searching time in a binary search tree : "+ (seconds) +" miliseconds");




}
}
