/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework10;
import  java.util.*;

public class CS401PriorityQueue<E>
{
   private static final int DEFAULT_INITIAL_CAPACITY = 11;

  /**
   * Priority queue represented as a balanced binary heap: the two
   * children of queue[n] are queue[2*n+1] and queue[2*(n+1)].  The
   * priority queue is ordered by comparator, or by the elements'
   * natural ordering, if comparator is null: For each node n in the
   * heap and each descendant d of n, n <= d.  The element with the
   * lowest value is in queue[0], assuming the queue is nonempty.
   */
   private transient Object[] queue;
   private int[] Heap;
   //private int size;
   private int maxsize;

   private static final int FRONT = 1;
   /**
     * The number of elements in the priority queue.
     */
    private int size = 0;

   /**
    * Creates a {@code PriorityQueue} with the default initial
    * capacity (11) that orders its elements according to their
    * {@linkplain Comparable natural ordering}.
    */
   public CS401PriorityQueue() {
        this(DEFAULT_INITIAL_CAPACITY);
    }

   /**
    * Creates a {@code PriorityQueue} with the specified initial
    * capacity that orders its elements according to their
    * {@linkplain Comparable natural ordering}.
    *
    * @param initialCapacity the initial capacity for this priority queue
    * @throws IllegalArgumentException if {@code initialCapacity} is less
    *         than 1
    */
   public CS401PriorityQueue(int initialCapacity) 
   {
      if (initialCapacity < 1)
          throw new IllegalArgumentException();
      this.queue = new Object[initialCapacity];
   }

    /**
     * Inserts the specified element into this priority queue.
     *
     * @return {@code true} (as specified by {@link Collection#add})
     * @throws ClassCastException if the specified element cannot be
     *         compared with elements currently in this priority queue
     *         according to the priority queue's ordering
     * @throws NullPointerException if the specified element is null
     */
    public boolean add(E e) {
        return offer(e);
    }
    
    
    
    

    /**
     * Inserts the specified element into this priority queue.
     *
     * @return {@code true} (as specified by {@link Queue#offer})
     * @throws ClassCastException if the specified element cannot be
     *         compared with elements currently in this priority queue
     *         according to the priority queue's ordering
     * @throws NullPointerException if the specified element is null
     */
    public boolean offer(E e) {
        if (e == null)
            throw new NullPointerException();
        int i = size;
        if (i >= queue.length)
            grow(i + 1);
        size = i + 1;
        if (i == 0)
            queue[0] = e;
        else
            siftUp(i, e);
        return true;
    }

   public E remove()  
   {
      if (size == 0)
         throw new NoSuchElementException();

      int s = --size;
      
      E elem = (E) queue[0];
      E last = (E) queue[s];
     
      queue[s] = null;
      if (s != 0) siftDown(0, last);

      return elem;
   }

   public String toString()
   {
      String s = "";
      
      for (int i = 0; i < size; i++)
         s += queue[i] + " ";

      return s;
   }

   /* --- Private methods --- */

   /**
    * Increases the capacity of the array.
    *
    * @param minCapacity the desired minimum capacity
    */
   private void grow(int minCapacity) {
        if (minCapacity < 0) // overflow
            throw new OutOfMemoryError();
      int oldCapacity = queue.length;
        // Double size if small; else grow by 50%
        int newCapacity = ((oldCapacity < 64)?
                           ((oldCapacity + 1) * 2):
                           ((oldCapacity / 2) * 3));
        if (newCapacity < 0) // overflow
            newCapacity = Integer.MAX_VALUE;
        if (newCapacity < minCapacity)
            newCapacity = minCapacity;
        queue = Arrays.copyOf(queue, newCapacity);
   }


   private void siftUp(int k, E x) 
   {
       Comparable<? super E> key = (Comparable<? super E>) x;
        while (k > 0) {
            int parent = (k - 1) >>> 1;
            Object e = queue[parent];
            if (key.compareTo((E) e) >= 0)
                break;
            queue[k] = e;
            k = parent;
        }
        queue[k] = key;
   }

   private void siftDown(int k, E x) 
   {
        Comparable<? super E> key = (Comparable<? super E>)x;
        int half = size >>> 1;        // loop while a non-leaf
        while (k < half) {
            int child = (k << 1) + 1; // assume left child is least
            Object c = queue[child];
            int right = child + 1;
            if (right < size &&
                ((Comparable<? super E>) c).compareTo((E) queue[right]) > 0)
                c = queue[child = right];
            if (key.compareTo((E) c) <= 0)
                break;
            queue[k] = c;
            k = child;
        }
        queue[k] = key;
   }
   
   //**************************************************************************************//
   
   public void MaxHeap(int maxsize)
   {
       this.maxsize = maxsize;
       this.size = 0;
       Heap = new int[this.maxsize + 1];
       Heap[0] = Integer.MAX_VALUE;
   }

   private int parent(int pos)
   {
       return pos / 2;
   }

   private int leftChild(int pos)
   {
       return (2 * pos);
   }

   private int rightChild(int pos)
   {
       return (2 * pos) + 1;
   }

   private boolean isLeaf(int pos)
   {
       if (pos >=  (size / 2)  &&  pos <= size)
       {
           return true;
       }
       return false;
   }

   private void swap(int fpos,int spos)
   {
       int tmp;
       tmp = Heap[fpos];
       Heap[fpos] = Heap[spos];
       Heap[spos] = tmp;
   }

   private void maxHeapify(int pos)
   {
       if (!isLeaf(pos))
       { 
           if ( Heap[pos] < Heap[leftChild(pos)]  || Heap[pos] < Heap[rightChild(pos)])
           {
               if (Heap[leftChild(pos)] > Heap[rightChild(pos)])
               {
                   swap(pos, leftChild(pos));
                   maxHeapify(leftChild(pos));
               }else
               {
                   swap(pos, rightChild(pos));
                   maxHeapify(rightChild(pos));
               }
           }
       }
   }

   public void insert(int element)
   {
       Heap[++size] = element;
       int current = size;

       while(Heap[current] > Heap[parent(current)])
       {
           swap(current,parent(current));
           current = parent(current);
       }	
   }
   
   

   public void print()
   {
       for (int i = 1; i <= size / 2; i++ )
       {
           System.out.print(" PARENT : " + Heap[i] + " LEFT CHILD : " + Heap[2*i]
                 + " RIGHT CHILD :" + Heap[2 * i  + 1]);
           System.out.println();
       }
   }

   public void maxHeap()
   {
       for (int pos = (size / 2); pos >= 1; pos--)
       {
           maxHeapify(pos);
       }
   }

//   public int remove()
//   {
//       int popped = Heap[FRONT];
//       Heap[FRONT] = Heap[size--]; 
//       maxHeapify(FRONT);
//       return popped;
//   }
   
   //**************************************************************************************
   
   
   public boolean offerstr(String string) {
       if ( string== null)
           throw new NullPointerException();
       int i = size;
       if (i >= queue.length)
           grow(i + 1);
       size = i + 1;
       if (i == 0)
           queue[0] = string;
       else
           siftUp(i, string);
       return true;
   }
   private void siftUp(int i, String string) {
	// TODO Auto-generated method stub
	
}

//**************************************************************************************
   public static void main(String...arg)
   {
       System.out.println("The Max Heap is ");
       MaxHeap maxHeap = new MaxHeap(15);
       maxHeap.insert(5);
       maxHeap.insert(3);
       maxHeap.insert(17);
       maxHeap.insert(10);
       maxHeap.insert(84);
       maxHeap.insert(19);
       maxHeap.insert(6);
       maxHeap.insert(22);
       maxHeap.insert(9);
       maxHeap.maxHeap();

       maxHeap.print();
       System.out.println("The max val is " + maxHeap.remove());
   }


   
   
   
   
   
   
 //**************************************************************************************//
   
}
