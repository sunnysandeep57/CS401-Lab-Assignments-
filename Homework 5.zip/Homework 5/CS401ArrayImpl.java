package homework5;

public class CS401ArrayImpl<E> implements CS401CollectionInterface<E> {

    private E[] elements;
    private int num_elements;
    private int capacity;

    @SuppressWarnings("unchecked")
    public CS401ArrayImpl(int size) {
        elements = (E[]) new Object[size];
        num_elements = 0;
        capacity = size;
    }

    @SuppressWarnings("unchecked")
    public CS401ArrayImpl() {
        /**
         * Call the c'tor that takes the 'size' parameter.  *
         */
        this(5);
    }

    /**
     * Methods inherited from CS401CollectionInterface
     */
    public boolean is_full() {
        if (num_elements == capacity) {
            return true;
        }
        return false;
    }

    public boolean is_empty() {
        if (num_elements == 0) {
            return true;
        }
        return false;
    }

    public int size() {
        return num_elements;
    }

    public boolean add(E e) {
        add(Where.BACK, e);  // Add at the end
        return true;
    }

    /*
    * Remove element at index i.  If the element exists in the collection, 
    * return that element back to the user.  If the index is out of bounds,
    * return null.
     */
    public E remove(int index) {
        E e;
        if (index < 0 || index > num_elements - 1) {
            throw new IndexOutOfBoundsException();
        }

        e = elements[index];

        for (int i = index + 1; i < num_elements; i++) {
            elements[i - 1] = elements[i];
        }

        num_elements--;
        return e;
    }

    /*
    * Return true if e is in the collection class, false otherwise.
     */
    public boolean contains(E e) {
       for (int i = 0; i < num_elements; i++)
          if (elements[i] == e)
              return true;
       
       return false;
    }

    /**
     * ---- Methods defined by this class
     * ---------------------------------------------------------- Methods that
     * are added by this class and not in the CS401CollectionInterface
     */
    /**
     * Add element in middle. Preconditions: where == MIDDLE index <=
     * num_elements - 1
     */
    public boolean add(Where where, int index, E e) {

        /* 
       * If there is no space to add the new element, grow the array. */
        if (is_full()) {
            grow();
        }

        /**
         * Add code here
         */
        if(where == Where.MIDDLE && index <= num_elements -1){
            int middle = (num_elements-1) / 2;
            
            for(int i = num_elements; i >= middle; i--){
                elements[i] = elements[i - 1];
            } 
            elements[middle] = e;
            num_elements++;
        }
        return true;
    }

    /**
     * Add element in front or at the end, as dictated by where. Preconditions:
     * where != MIDDLE
     */
    public boolean add(Where where, E e) {

        /* 
       * If there is no space to add the new element, grow the array. */
        if (is_full()) {
            grow();
        }

        if (where == Where.BACK) {
            System.out.println("Inserting element at index " + num_elements);
            elements[num_elements] = e;
            num_elements++;
        } else if (where == Where.FRONT) {
            System.out.println("Inserting element at index 0");
            System.out.println("Compacting storage");
            /*
           * Add code here.
           * You will add the new element at index 0, and shift all the
           * elements down by one. */
            for(int i = num_elements; i > 0; i--){
                elements[i] = elements[i - 1];
            }
            elements[0] = e;
            num_elements++;
        }

        return true;
    }

    /*
    * Gets the element at index i (0 <= i <= num_elements-1)
     */
    public E get(int i) {

        if (i < 0 && i > num_elements) {
            return null;
        }

        return (elements[i]);
    }

    /**
     * ----------- Private methods
     */
    /*
    * Grows elements array to hold more elements.  Copies old (existing)
    * elements in the new array.
    * 
    * Postcondition: (a) elements must contain the contents of the old array
    *                (b) elements must now have twice as much capacity as
    *                    before
     */
    @SuppressWarnings("unchecked")
    private boolean grow() {

        /* 
       * Add code here 
       * Expand capacity (double it) and copy old array contents to the
       * new one. 
         */
        
        System.out.println("Capacity reached.  Increasing storage...");
        capacity = capacity * 2;
        E[] new_elements;
        new_elements = (E[]) new Object[capacity]; 
        for(int i = 0; i <= num_elements - 1; i++){
            new_elements[i] = elements[i];
            
        }
        
        elements = (E[]) new Object[capacity];
        for(int i = 0; i <= num_elements - 1; i++){
            elements[i] = new_elements[i];
            
        }
        System.out.println("New capacity is " + capacity + " elements");

        return true;
    }
    
    /*public enum Where{
        FRONT, MIDDLE, BACK
    }*/

    CS401ArrayImpl<Integer> subList(int i, int j) {
        CS401ArrayImpl<Integer> sublist = new CS401ArrayImpl<Integer>();
        
        //for (int k = i; k < j; k++){
            //sublist.add(CS401ArrayTest.numbers.get(k));
            //return sublist(int i,int j);
            // List<String> sublist = al.subList(1, 4);
            sublist.add(200);
            sublist.add(300);
            sublist.add(400);
        //}
        return sublist;
    }
    
}
