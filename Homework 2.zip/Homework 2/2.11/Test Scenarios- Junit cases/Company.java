package Homework2;

import java.util.*;
import java.io.*; // for the FileNotFoundException class � see Section 2.3

public class Company {

    public static void main(String[] args) throws FileNotFoundException {

//        new Company().run();
        
        System.out.println("New Test Scenarios: ");
        FullTimeEmployeeEqualsTest fteet = new FullTimeEmployeeEqualsTest();
        fteet.testConsistency();
        fteet.testReflexivity();
        fteet.testSymmetry();
        fteet.testTransitivity();
        fteet.testuActuality();
    }
    

    public void run() throws FileNotFoundException // see Section 2.3
    {
        //to provide the user input for the values of below variables
        try {
            System.out.println("Enter the value for x,y,z");
            Scanner sc1 = new Scanner(System.in);
            //User input the value for x
            System.out.println("Enter the value of x");
            String a = sc1.next();
            double d = sc1.nextDouble();
            //User input the value for y
            System.out.println("Enter the value of y");
            String b = sc1.next();
            double f = sc1.nextDouble();
            //User input the value for z
            System.out.println("Enter the value of z");
            String c = sc1.next();
            double g = sc1.nextDouble();

            FullTimeEmployee f1 = new FullTimeEmployee(a, d);
            FullTimeEmployee f2 = new FullTimeEmployee(b, f);
            FullTimeEmployee f3 = new FullTimeEmployee(c, g);

            // Condition to check if equals satisfies reflexivity
            System.out.println("\n1)Reflexivity");
            if (f1 != null) {
                System.out.println("x.equals(x) = " + f1.equals(f1));
                System.out.println("Satisfies reflexivity");
            }

            // Condition to check if it satisfies symmetry
            System.out.println("\n2)Symmetry");
            if (f1 != null && f2 != null) {
                System.out.println("x.equals(y) = " + f1.equals(f2));
                System.out.println("y.equals(x) = " + f2.equals(f1));
                System.out.println("It satisfies symmetric");
            }

            // method is transitive
            System.out.println("\n3)Transitivity");
            if (f1.equals(f2) == true && f2.equals(f3) == true) {
                System.out.println("Transitivity: For any references x, y and z if x.equals(y) returns true, and y.equals (z) returns true, then x.equals (z) should return true.");
                System.out.println("x.equals(y) = " + f1.equals(f2));
                System.out.println("y.equals(x) = " + f2.equals(f3));
                System.out.println("x.equals(z) = " + f1.equals(f3));
                System.out.println("It is transitive");
            } else {
                System.out.println("\n x.equals(y) = " + f1.equals(f2));
                System.out.println("y.equals(x) = " + f2.equals(f3));
                System.out.println("x.equals(z) = " + f1.equals(f3));
                System.out.println("It is not transitive");
            }
            //consistency Property
            System.out.println("\n\n4)Consistency");
            if (f1 != null && f2 != null) {
                System.out.println("Enter the value of n for multiple calls");
                int n = sc1.nextInt();
                boolean old = f1.equals(f2);
                int i = 0;
                do {
                    System.out.println("x.equals(y) for count " + i + "= "
                            + f1.equals(f2));
                    if (old != f1.equals(f2)) {
                        System.out.println("It is not consistent ");
                    }
                    i++;
                } while (i < n);
                System.out.println("It is consistent ");
            }
            /* Example to show that equals method satisfies actuality */
            System.out.println("\n\n5)Actuality");
            if (f1 != null) {
                System.out.println("x.equals(null)=" + f1.equals(null));
                System.out.println("It satisfies actuality");
            }

        } catch (NullPointerException e) {
            System.out.println("Null value entered");
        } catch (InputMismatchException e) {
            System.out.println("Wrong Input,Please provide the input correctly");
        }

    }
}
