package Homework2;

import Homework2.FullTimeEmployee;
import Homework2.FullTimeEmployee;
import static org.junit.Assert.*;
import org.junit.Test;

public class FullTimeEmployeeEqualsTest {

    public void testuActuality() {
        System.out.println("Satisfies Actuality");
        FullTimeEmployee f1 = new FullTimeEmployee("Sandeep Adhikari", 90.00);
        assertTrue(f1.equals(null) == false);
    }

    public void testReflexivity() {
       System.out.println("object class equals method is reflexive");
        FullTimeEmployee f1 = new FullTimeEmployee("Sandeep Adhikari", 90.00);
        assertTrue(f1.equals(f1) == true);
    }

    public void testSymmetry() {
        System.out.println("object class equals method is symmetric");
        FullTimeEmployee f1 = new FullTimeEmployee("Sandeep Adhikari", 90.00);
        FullTimeEmployee f2 = new FullTimeEmployee("Sandeep Adhikari", 90.00);
        assertTrue(f1.equals(f2) == f2.equals(f1));
    }

    public void testTransitivity() {
        System.out.println("Test if object class equals method is Transitive");
        FullTimeEmployee f1 = new FullTimeEmployee("Sandeep Adhikari", 90.00);
        FullTimeEmployee f2 = new FullTimeEmployee("Sandeep Adhikari", 90.00);
        FullTimeEmployee f3 = new FullTimeEmployee("Sandeep Adhikari", 90.00);
        assertTrue(f1.equals(f2) == f2.equals(f3) == f3.equals(f1) == true);
    }

    public void testConsistency() {
        System.out.println("Test if object class equals method is Consistent");
        FullTimeEmployee f1 = new FullTimeEmployee("Sandeep Adhikari", 90.00);
        FullTimeEmployee f2 = new FullTimeEmployee("Sandeep Adhikari", 90.00);
        int n = 100;
        for (int i = 0; i < n; i++) {
            assertTrue(f1.equals(f2) == true);
        }

    }

}
