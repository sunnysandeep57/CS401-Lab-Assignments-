/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Homework212;

/**
 *
 * @author sunnysandeep
 */
import java.util.Comparator;

public class Equality  {
   public static void main(String[] args)  {

      MyPoint p1 = new MyPoint(10, 20);
      MyPoint p2 = new MyPoint(30, 40);
      MyPoint p3 = new MyPoint(10, 20);
      MyPoint p4 = new MyPoint(5, 25);
      MyPoint p5 = new MyPoint(15, 18);

      System.out.println(p1.equals(p2));
      System.out.println(p1.equals(p3));
      System.out.println(p1 == p2);
      System.out.println(p1 == p3);


      System.out.println(p1.compareTo(p2));
      System.out.println(p1.compareTo(p3));
      System.out.println(p1.compareTo(p4));
      System.out.println(p1.compareTo(p5));

      MyPointComparator mp_comp = new MyPointComparator();

      System.out.println(mp_comp.compare(p1, p2));
      System.out.println(mp_comp.compare(p1, p3));
      System.out.println(mp_comp.compare(p1, p4));
      System.out.println(mp_comp.compare(p1, p5));

      return;
   }
}

class MyPoint implements Comparable<MyPoint>  {
      public Integer x, y;

      public MyPoint(Integer arg_x, Integer arg_y)  {
         x = arg_x;
         y = arg_y;
      }

      public String toString()  {

         return "MyPoint[x=" + x + ",y=" + y + "]";
      }

      public boolean equals(MyPoint arg)   {
         boolean eq = false;
 
         if (this.x == arg.x)  {
             if (this.y == arg.y)
                 eq = true;   
         } 
        
         return eq;
      }

      public int compareTo(MyPoint arg)  {
         int eq;

         if (this.x == arg.x && this.y == arg.y)
             eq = 0;
         else if (this.x > arg.x)
             eq = 1;
         else
             eq = -1;

         return eq;
      }
}

class MyPointComparator implements Comparator<MyPoint>  {

   public int compare(MyPoint arg1, MyPoint arg2)  {

         int eq;

         if (arg1.x == arg2.x && arg1.y == arg2.y)
             eq = 0;
         else if (arg1.x > arg2.x)
             eq = 1;
         else
             eq = -1;

         return eq;
   }

   public boolean equals(MyPoint arg)  {
      return false;
   }
}
