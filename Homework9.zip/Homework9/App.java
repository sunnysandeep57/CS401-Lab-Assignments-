/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework9;


public class App {
	public static void main(String[] args) {
		Node A = Node.createNode(90);
		Node B = Node.createNode(80);
		Node C = Node.createNode(60);
		Node D = Node.createNode(25);
		Node E = Node.createNode(55);
		Node F = Node.createNode(35);
		Node G = Node.createNode(75);
		Node H = Node.createNode(10);
		Node I = Node.createNode(20);

		// connect Level 0 and 1
		A.left  = B;
		A.right = C;
		// connect level 1 and level 2
		B.left  = D;
		B.right = E;
		C.left  = F;
		C.right = G;
		// connect level 2 and level 3
		E.left  = H;
		F.right = I;

		int height = TreeHeight.TreeHeight(A);
		if (height > 0) {
			System.out.println("Height of a Binary Tree is : " + height + " and its run-time is O(logn)" );
		} else {
			System.out.println("Unable to calculate the height of a binary tree");
		}
	}
}
