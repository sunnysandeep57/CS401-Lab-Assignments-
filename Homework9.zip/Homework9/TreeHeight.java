/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework9;

public class TreeHeight {
	
	public static int TreeHeight(Node root) {
		if (null == root)
			return 0;
		int LeftSub = TreeHeight(root.left);
		int RightSub = TreeHeight(root.right);
		return Math.max(LeftSub, RightSub) + 1;
	}
}
