/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework9;

public class CS401BSTArray<E extends Comparable <E>> {
   protected TreeNode<E> [] tree;
   protected int root, size, indx;
	
   public CS401BSTArray() {
       /**
        * Do not initialize tree as: tree=(TreeNode<E> []) new Object[50];
        * While this will compile, it will throw a ClassCastException
        * when run.  Instead, use the initialization below.  Even the one
        * shown below is not the best, since Java does not allow a clean
        * way to allocate memory to hold an array of generic class objects.
        * For more information, see
        * https://courses.cs.washington.edu/courses/cse332/10su/notes/
        * genericArrays.html 
        * (Mind the line break in the above URL.  When you go to the above
        * URL, see Workaround #2.) */

      tree =  (TreeNode<E>[]) new TreeNode[50];
      root = 0;
      size = 0;
      indx = 0;
   }

   protected static class TreeNode<E> {
      E element;
      int parent, left, right;
      
      public TreeNode (E element, int parent, int left, int right) {
         this.element = element;
         this.parent = parent;
         this.left = left;
         this.right = right;
      }
   }

   public boolean add(E element)  {

      boolean r = false;
     
      /**
       * Example code to demonstrate creating a simple tree.  You will
       * replace this code to create a more complex tree */
      if (indx == 0)  {
         tree[indx] = new TreeNode(element, -1, -1, -1);
         r = true;
      }
      else{
          rec_add(element, 0);
      }

      indx++;
      size++;

      return r;
   }
   
   public int size(){
       return size;
   }
   
   public String inorder(){
       String inorder = "";
       inorder(0, inorder);
       System.out.println(inorder);
       return inorder;
   }
   
   private void inorder(int parent , String acc){
       if(tree[parent].left != -1)
        inorder(tree[parent].left, acc);
       System.out.print(tree[parent].element);
       System.out.print(", ");
       if(tree[parent].right != -1)
        inorder(tree[parent].right, acc);
   }
   
   private boolean rec_add(E element, int parent){
       if(indx > 0){
           int comp;
           comp = element.compareTo(tree[parent].element);
           if(comp < 0){
               if(tree[parent].left == -1){
                   tree[indx] = new TreeNode(element, parent, -1, -1);
                   tree[parent].left = indx;
                   return true;
               }
               rec_add(element, tree[parent].left);
           }else{
                if(tree[parent].right == -1){
                   tree[indx] = new TreeNode(element, parent, -1, -1);
                   tree[parent].right = indx;
                   return true;
                }
               rec_add(element, tree[parent].right);
           }
       }
       return false;
   }
   
   public boolean contains(E element){
       for(int i = 0; i <= size; i++){
           if(element.compareTo(tree[i].element) == 0)
               return true;
       }
       return false;
   }
   
   public boolean remove(E element){
       return(remove(element, 0));
   }
   
   private boolean remove(E element, int parent){
       
           int comp;
           comp = element.compareTo(tree[parent].element);
           if(comp < 0){
               if(tree[parent].left != -1){
                   return remove(element, tree[parent].left);
               }else{
                   return false;
               }
           }else if(comp > 0){
               if(tree[parent].right != -1){
                   return remove(element, tree[parent].right);
               }else{
                   return false;
               }
           }else{
               try{
               if(tree[parent].left != -1 && tree[parent].right != -1){
                   tree[parent].element = minValue(tree[parent].right);
                   remove(element, tree[parent].right);
               }else if(tree[tree[parent].left] == tree[parent]){
                   tree[parent].left = (tree[parent].left != -1) ? tree[parent].left : tree[parent].right;
               }else if(tree[tree[parent].right] == tree[parent]){
                   tree[parent].right = (tree[parent].left != -1) ? tree[parent].left : tree[parent].right;
               }
               }
               catch(Exception E){
//                   E.printStackTrace();
               }
           }
       return true;
   }
   
   private E minValue(int parent){
       if(tree[parent].left == -1){
           return tree[parent].element;
       }else{
           return minValue(tree[parent].left);
       }
   }
   
   protected TreeNode<E> getTreeNode(E element){
       return null;
   }
   
   protected TreeNode<E> deleteTreeNode(TreeNode<E> node){
       return null;
   }
   
   protected TreeNode<E> successor(TreeNode<E> node){
       return null;
   }

   /**
    * print - Prints the array based tree as a table with 4 columns.
    */
   void print()  {
      int indx;

      for (indx = 0; indx < size; indx++)  {
         System.out.println(tree[indx].element + ", " +
                            tree[indx].parent  + ", " +
                            tree[indx].left    + ", " +
                            tree[indx].right);
      }
   }

   public static void main(String[] args)  {
      CS401BSTArray<Integer> myGenClassArray = new CS401BSTArray<Integer>();
      
      myGenClassArray.add(33);
      myGenClassArray.add(20);
      myGenClassArray.add(40);
       
      myGenClassArray.print();
   }
}
