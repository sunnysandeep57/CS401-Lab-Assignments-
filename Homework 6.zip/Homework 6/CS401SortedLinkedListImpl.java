/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework6;

import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Itzsunnysandeep
 */
public class CS401SortedLinkedListImpl<E> extends CS401LinkedListImpl<E>
{
//    protected LinkEntry<E> head;
//   protected LinkEntry<E> tail;
//   protected int num_elements = 0;
   public CS401SortedLinkedListImpl()
   {
      super();
   }

   /** 
    * Adds element e in sorted order in the collection class (linked 
    * list).
    * Returns true if e was added successfully, false otherwise.
    */
   public boolean add(E e)
   {
        
      /**
       * Add code here. */
       if(head == null && tail == null){
           return add(Where.BACK, e);
       }
       
       LinkEntry<E> ne = new LinkEntry<E>();
       ne.element = e;
       
       LinkEntry<E> current = head;
        LinkEntry<E> previous = null;
        E[] parameters = (E[]) Array.newInstance(e.getClass(), 1);
        
        
        try {
            Class[] methodParams = new Class[1];
            methodParams[0] = e.getClass();
            Method compareMethod = e.getClass().getMethod("compareTo", methodParams);
            parameters[0] = current.element;
            while((int)compareMethod.invoke(e, parameters) > 0){
                
                previous = current;
                current = current.next;
                if(current == null)
                    break;
                parameters[0] = current.element;
            }
        } catch (Exception ex) {
            Logger.getLogger(CS401SortedLinkedListImpl.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
       
       if(previous == null){
           ne.next = head;
           head = ne;
       } else {
           ne.next = previous.next;
           previous.next = ne;
       }
       num_elements++;
       
//       LinkEntry<E> current = head;
//       while(current != null){
//           if(e.){
//               
//           }
//       }
       
      return true;
   }

   /**
    * Print the sorted linked list in reverse order using recursion.
    */
   public void reverse_print()  {
      /**
       * Add code here 
       */
      System.out.println(print_reverse(head));
   }
   
   private String print_reverse(LinkEntry<E> subList){
       if(subList.next == null){
           return subList.element.toString();
       }
       String preStr = print_reverse(subList.next);
       StringBuilder result = new StringBuilder();
       result.append(preStr);
       result.append(subList.element);
        
          

      return result.toString();
       
   }
   
   public boolean add(Where where, E e)  {

      if (where == Where.MIDDLE) 
          return false;

      LinkEntry<E> ne = new LinkEntry<E>();
      ne.element = e;

      if (head == null && tail == null)
      {
          head = tail = ne;
          num_elements++;
          return true;
      }

      if (where == Where.BACK) {
         tail.next = ne;
         tail = ne;
      }
      else if (where == Where.FRONT)  {
          /**
           * Add code here. */
          ne.next = head;
          head = ne;
      }
      num_elements++;
      return true;
   }
   
  
} /* CS401SortedLinkedListImpl<E> */

